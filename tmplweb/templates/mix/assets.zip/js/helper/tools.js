function redirectUrl(url) {
    window.location.href = url
}
function ajaxPost(url, data, fnOk, fnNok) {
    $.ajax({
        url: url,
         type: 'POST',
         data: ko.mapping.toJSON(data),
         contentType: "application/json; charset=utf-8",
         beforeSend: function() {
             model.Processing(true);
         },
         success: function (data) {
             if (typeof fnOk == "function") fnOk(data);
             koResult = "OK";
             model.Processing(false);
         },
         error: function (error) {
             model.Processing(false);
             if (typeof fnNok == "function") {
                 fnNok(error);
             }
             else {
                 alert("There was an error posting the data to the server: " + error.responseText);
             }
         }
     });
 }

 function removeSpace(str) {
     return str.replace(" ", "");
 }

 function capitalize(str) {
     return str.charAt(0).toUpperCase()+str.slice(1);
 }

 function findMenu(arr, id) {
    for(var i = 0; i < arr.length; i++) {
        if(arr[i].Id == id)
            return arr[i];
        else {
            var foundSub = null;
            if(typeof arr[i].SubMenu != 'undefined') foundSub = findMenu(arr[i].SubMenu, id);
            if(foundSub) return foundSub;
        }
    }
}

function generateTreeMenu(arr) {
    var result = [];
    _.each(arr, function(o) {
        if(o.Parent == "") {
            result.push(o);
        } else {
            var parent = findMenu(arr, o.Parent);
            if(parent) {
                if(typeof parent.SubMenu != 'undefined') parent.SubMenu.push(o);
                else parent.SubMenu = [o];
            }
        }
    })
    return result;
}

function generateBreadcrumb(arr, pageId) {
    var breadcrumb = [];
    for(var i = 0; i < arr.length; i++) {
        if(arr[i].PageId == pageId) {
            breadcrumb.push(arr[i]);
            return breadcrumb;
        }else if(arr[i].SubMenu) {
            var fromSub = generateBreadcrumb(arr[i].SubMenu, pageId);
            if(fromSub) {
                breadcrumb.push(arr[i]);
                breadcrumb = breadcrumb.concat([fromSub[0]]);
                return breadcrumb;
            }
        } 
    }
}

function kb2gb(kb) {
    return (kb / (1024 * 1024)).toFixed(2);
}

function convertByte(b, type) {
    switch(type) {
        case "GB" :
            return parseFloat((b / (1024 * 1024 * 1024)).toFixed(2))
            break;
        case "MB" :
            return parseFloat((b / (1024 * 1024)).toFixed(2))
            break;
        case "KB" :
            return parseFloat((b / (1024)).toFixed(2))
            break;
        default:
            return parseFloat(b.toFixed(2));
    }
}

function averagedLabel(arr) {
    var mean = _.mean(arr);
    console.log(mean);
    if(mean > (1024*1024*1024)) return "GB";
    else if(mean > (1024*1024)) return "MB";
    else if(mean > (1024)) return "KB";
    else return "B";
}