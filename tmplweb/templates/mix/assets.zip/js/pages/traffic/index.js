var Traffic = {};
Traffic.ServiceStatus = {
    INIT : "red",
    INSTALLING : "red",
    INSTALL_FAILED : "red",
    INSTALLED : "red",
    STARTING : "red",
    STARTED : "green",
    STOPPING : "red",
    UNINSTALLING : "red",
    UNINSTALLED : "red",
    WIPING_OUT : "red",
    UPGRADING : "red",
    DISABLE : "red",
    UNKNOWN : "amber",
}
Traffic.Search = ko.observable("");
Traffic.searchSubmit = function() {
    Traffic.Grid.nonprod.filter(Traffic.Search());
    Traffic.Grid.prod.filter(Traffic.Search());
}

function GridServer(serverType, selector) {
    var self = this;
    self.type = serverType;
    self.dataGrid = null;
    self.title = serverType == "prod" ? "Production" : "Non Production";
    self.object = [];
    self.mode = ko.observable("normal"); // normal || prod || nonprod
    self.data = [];
    self.servers = [];
    self.column = [{
        title: self.title,
        field: "ServerType.value",
        width: 200,
        attributes: { class: "text-center" },
        template: function(t) {
            var type = self.evaluateColumn(t.toJSON());
            return "<a class='server-cell "+type+"' onclick='serverTypeClick(\""+t.ServerType.valIp+"\")'>"+t.ServerType.value+"<br />"+t.ServerType.valIp+"</a>";
        },
        headerAttributes: { class: "grid-type" },
        headerTemplate : "<a onclick='expand(\""+self.type+"\")'>"+self.title+"</a>",
    }];
    self.evaluateColumn = function(row) {
        var isRed = false;
        var isGreen = true;
        var allEmpty = true;
        var keys = Object.keys(row);
        for(var i = 0; i < keys.length; i++) {
            if(row[keys[i]].type == "red") {
                isRed = true;
                break;
            }
            if(row[keys[i]].type != "") allEmpty = false;
            if(row[keys[i]].type == "amber") isGreen = false;
        }
        if(isRed) return "red";
        if(allEmpty) return "";
        if(isGreen) return "green";
        return "";
    }
    self.getData = function(payload) {
        var prom = new Promise(function(resolve, reject) {
            ajaxPost("/traffic/gettrafficinfo", payload, function(res) {
                self.buildData(res.Data[self.type]);
                self.buildColumns(res.Data[self.type].Header);
                resolve(true);
            }, function() {
                reject(false);
            });
        });
        return prom;
    };
    self.buildData = function(data) {
        var _data = [];
        var _servers = [];
        var header = data.Header != null ? data.Header : [];
        var data = data.Data != null ? data.Data : [];
        for(var i = 0; i < data.length; i++) {
            var row = { ServerType: { type: "", value: data[i].NodeName, valIp: data[i].NodeIp } };
            for(var x = 0; x < data[i].Values.length; x++) {
                row[header[x].ComponentName] = {
                    type: data[i].Values[x] == "" ? "" : Traffic.ServiceStatus[data[i].Values[x]],
                    value: data[i].Values[x] == "" ? "" : data[i].NodeName,
                    valIp: data[i].Values[x] == "" ? "" : data[i].NodeIp
                };
            }
            _data.push(row);
            _servers.push({ name: data[i].NodeName, ip: data[i].NodeIp });
        }
        self.data = self.data.concat(_data);
        self.servers = _servers;
    };
    self.filter = function(str){
        var grid = self.dataGrid;
        if(str != "") {
            var data = _.filter(self.data, function(d) {
                var name = d.ServerType.value;
                var ip = d.ServerType.valIp;
                return name.indexOf(str) > -1 || ip.indexOf(str) > -1;
            });
            grid.dataSource.data(data);
        } else {
            grid.dataSource.read();
        }
        grid.refresh();
        var lockedContent = grid.wrapper.children(".k-grid-content-locked")
        var content = grid.wrapper.children(".k-grid-content");
        grid.wrapper.height("");
        lockedContent.height("");
        content.height("");
        grid.wrapper.height(grid.wrapper.height());
        grid.resize();
    }
    self.buildColumns = function(header) {
        var _columns = [];
        var header = header != null ? header : [];
        if(header.length > 0) self.column[0].locked = true;
        for(var i = 0; i < header.length; i++) {
            _columns.push(self.columnTemplate(header[i]));
        }
        self.column = self.column.concat(_columns);
    }
    self.columnTemplate = function(col) {
        return {
            title: col.DisplayName,
            field: col.ComponentName,
            width: 150,
            attributes: { class: "text-center"},
            template: function(t) {
                return "<a onclick='cellClick(\""+t[col.ComponentName].valIp+"\")' class='server-cell "+t[col.ComponentName].type+"'>"+t[col.ComponentName].value+"</a>";
            },
            headerTemplate : "<a onclick='headerClick(\""+self.type+"\",\""+col.ComponentName+"\")'>"+col.DisplayName+"</a>",
            headerAttributes : {
                class: "server-grid"
            }
        }
    };
    self.buildGrid = function() {
        $(selector).kendoGrid({
            dataSource: {
                data: self.data,
                pageSize: 10,
            },
            scrollable: true,
            pageable: true,
            columns: self.column
        });
        self.dataGrid = $(selector).data("kendoGrid");

        if(self.column.length > 1) {
            var grid = self.dataGrid;
            var lockedContent = grid.wrapper.children(".k-grid-content-locked")
            var content = grid.wrapper.children(".k-grid-content");

            grid.wrapper.height("");
            lockedContent.height("");
            content.height("");

            grid.wrapper.height(grid.wrapper.height());

            grid.resize();
        }
        return self.dataGrid;
    }
    self.render = function() {
        self.getData({ ClusterType: self.type })
            .then(function() {
                return self.buildGrid();
            })
            .catch(function() {
                alert("failed getData");
            });
    }
}

Traffic.Grid = {
    prod: new GridServer("prod", "#gridPrd"),
    nonprod: new GridServer("nonprod", "#gridNonPrd"),
}

Traffic.Modal = {
    leftHeader: ko.observable(""),
    rightHeader: ko.observable("")
}
function headerClick(type, component) {
    ajaxPost("/nodeinfo/getdigitalpassportos", { "clustertype": type, "componentname": component}, function(res) {
        if(res.Data.length > 0) {
            Traffic.Modal.leftHeader("<p>"+res.Data[0].ClusterName+"</p><p>Last Updated: "+moment(res.Data[0].Timestamp).format("DD/MM/YYYY")+"</p>");
            Traffic.Modal.rightHeader("");
        }
        Traffic.initHeaderGrid(res.Data);
        $("#modalDetail").modal('show');
    });
}
function cellClick(ip) {
    ajaxPost("/nodeinfo/getservicelistbyip", { "HostIp": ip}, function(res) {
        if(res.Data) {
            Traffic.Modal.leftHeader("<p>"+res.Data.nodename+"</p><p>Last Updated: "+moment(res.Data.lastupdate).format("DD/MM/YYYY")+"</p>");
            Traffic.Modal.rightHeader("<p>O/S: "+res.Data.osname+"</p><p>Kernel: "+res.Data.oskernel+"</p>");
        }
        Traffic.initCellGrid(res.Data.services);
        $("#modalDetail").modal('show');
    });
}
function serverTypeClick(host) {
    ajaxPost("/nodeinfo/getdigitalpassportbyhostip", { HostIp: host }, function(res) {
        if(res.Data.length > 0) {
            Traffic.Modal.leftHeader("<p>"+res.Data[0].ClusterName+"</p><p>Last Updated: "+moment(res.Data[0].Timestamp).format("DD/MM/YYYY")+"</p>");
            Traffic.Modal.rightHeader("");
        }
        Traffic.initHostGrid(res.Data);
        $("#modalDetail").modal('show');
    })
};

function expandDetailGrid(elem) {
    var tr = $(elem).closest("tr");
    if(tr.hasClass("expand")){
        $("#gridModal").data().kendoGrid.collapseRow(tr);
        tr.removeClass("expand");
    } else {
        $("#gridModal").data().kendoGrid.expandRow(tr);
        tr.addClass("expand");
    }
    $(".k-detail-row .k-hierarchy-cell").remove();
}
function expand(type) {
    $("."+type).css("display", "block");
    if(type == "prod") {
        $(".nonprod").css("display", "none");
        $(".prod").removeClass("split");
        $(".prod").addClass("full");
    }
    if(type == "nonprod") {
        $(".prod").css("display", "none");
        $(".nonprod").removeClass("split");
        $(".nonprod").addClass("full");
    }

    var grid = Traffic.Grid[type].dataGrid;
    var lockedContent = grid.wrapper.children(".k-grid-content-locked")
    var content = grid.wrapper.children(".k-grid-content");

    grid.wrapper.height("");
    lockedContent.height("");
    content.height("");

    grid.wrapper.height(grid.wrapper.height());

    grid.resize();
    grid.refresh();
    var header = $("."+type).find(".grid-type");
    header.addClass("dropdown-header");
    header.html("<input class='dropdownType' />");
    var gridType = [
        { type: "prod", title: "Production" },
        { type: "nonprod", title: "Non Production" },
    ]
    $("."+type).find(".dropdownType").kendoDropDownList({
        dataSource: {
            data: gridType
        },
        value: type,
        dataTextField: "title",
        dataValueField: "type",
        change: function() {
            expand(this._old);
        }
    })
}

Traffic.initHostGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HostName" },
            pageSize: 10
        },
        detailTemplate: "Disk Spaces: <div class='detailGrid'></div>",
        pageable: true,
        detailInit: function(e) {
            e.detailRow.find(".detailGrid").kendoGrid({
                dataSource: e.data.DiskSpace,
                columns: [
                    {title: "File System", field: "FileSystem", attributes: { class: "text-left" } },
                    {title: "Mounted On", field: "MountedOn", attributes: { class: "text-left" } },
                    {title: "Total", field: "Total", attributes: { class: "text-right" } , template: function(o) { return autoConvertKByte(o.Total) }},
                    {title: "Available", field: "Available", attributes: { class: "text-right" } , template: function(o) { return autoConvertKByte(o.Available) }},
                    {title: "Used", field: "Used", attributes: { class: "text-right" } , template: function(o) { return autoConvertKByte(o.Used) }},
                    {title: "%", field: "UsedCapacity", attributes: { class: "text-right" } , template: function(o) { return o.UsedCapacity.toFixed(2) + "%" }},
                ]
            })
        },
        dataBound: function() {
            $(".k-hierarchy-cell").hide();
            $(".k-hierarchy-col").remove();
        },
        sortable: true,
        columns: [
            { title: "Server", field: "HostName", attributes: { class: "text-left" } },
            { title: "CPU", field: "CpuCount", width: 80 },
            { title: "O/S", field: "OsName", width: 80, attributes: { class: "text-left" } },
            { title: "Kernel", field: "OsKernel", attributes: { class: "text-left" }  },
            { title: "Status", field: "", attributes: { class: "text-left" } },
            { title: "Storage", field: "DiskTotal", attributes: { class: "text-right" } , template: function(t) { return "<a onclick='expandDetailGrid(this)'>"+(t.DiskPct.toFixed(2) + "%")+"</a>"} },
            { title: "Version", field: "OsVersion", attributes: { class: "text-left" }  },
        ]
    })
}
Traffic.initHeaderGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HostName" },
            pageSize: 10,
        },
        sortable: true,
        pageable: true,
        columns: [
            { title: "Server", field: "HostName", attributes: { class: "text-left" }  },
            { title: "Version", field: "CpuCount", attributes: { class: "text-right" } , width: 80 },
            { title: "O/S", field: "OsName", attributes: { class: "text-left" } , width: 80 },
            { title: "Kernel", field: "OsKernel", attributes: { class: "text-left" }  },
            { title: "Status", field: "" },
        ]
    })
}
Traffic.initCellGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HR_DisplayName" },
            pageSize: 10,
        },
        sortable: true,
        pageable: true,
        columns: [
            { title: "Services", field: "HR_DisplayName", attributes: { class: "text-left" }  },
            { title: "Version", field: ""},
            { title: "Vendor", field: "" },
            { title: "Last Update", field: "" },
            { title: "Status", field: "HR_State", attributes: { class: "text-left" } , template: function(o) { return Traffic.ServiceStatus[o.HR_State]} },
            { title: "Upgrade Plan", field: "" },
        ]
    })
}

Traffic.generateProductionGrid = function() {
    Traffic.Grid.prod.render();
}
Traffic.generateNonProductionGrid = function() {
    Traffic.Grid.nonprod.render();
}

Traffic.init = function() {
    this.generateNonProductionGrid();
    this.generateProductionGrid();
}

$(function() {
    Traffic.init();
})