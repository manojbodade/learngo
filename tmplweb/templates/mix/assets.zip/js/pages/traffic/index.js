var Traffic = {};
Traffic.ServiceStatus = {
    INIT : "danger",
    INSTALLING : "danger",
    INSTALL_FAILED : "danger",
    INSTALLED : "danger",
    STARTING : "danger",
    STARTED : "good",
    STOPPING : "danger",
    UNINSTALLING : "danger",
    UNINSTALLED : "danger",
    WIPING_OUT : "danger",
    UPGRADING : "danger",
    DISABLE : "danger",
    UNKNOWN : "warning",
}

function GridServer(serverType, selector) {
    var self = this;
    self.type = serverType;
    self.dataGrid = null;
    self.title = serverType == "prod" ? "Production" : "Non Production";
    self.object = [];
    self.mode = ko.observable("normal"); // normal || prod || nonprod
    self.data = [];
    self.column = [{
        title: self.title,
        field: "ServerType.value",
        width: 150,
        attributes: { class: "text-center" },
        template: function(t) {
            return "<a class='server-cell' onclick='serverTypeClick(\""+t.ServerType.value+"\")'>"+t.ServerType.value+"</a>";
        },
        headerAttributes: { class: "grid-type" },
        headerTemplate : "<a onclick='expand(\""+self.type+"\")'>"+self.title+"</a>",
    }];

    self.getData = function(payload) {
        var prom = new Promise(function(resolve, reject) {
            ajaxPost("/traffic/gettrafficinfo", payload, function(res) {
                self.buildData(res.Data[self.type]);
                self.buildColumns(res.Data[self.type].Header);
                resolve(true);
            }, function() {
                reject(false);
            });
        });
        return prom;
    };
    self.buildData = function(data) {
        var _data = [];
        var header = data.Header != null ? data.Header : [];
        var data = data.Data != null ? data.Data : [];
        for(var i = 0; i < data.length; i++) {
            var row = { ServerType: { type: "", value: data[i].NodeIp } };
            for(var x = 0; x < data[i].Values.length; x++) {
                row[header[x].ComponentName] = {
                    type: data[i].Values[x] == "" ? "" : Traffic.ServiceStatus[data[i].Values[x]],
                    value: data[i].Values[x] == "" ? "" : data[i].NodeIp
                };
            }
            _data.push(row);
        }
        self.data = self.data.concat(_data);
    };
    self.buildColumns = function(header) {
        var _columns = [];
        var header = header != null ? header : [];
        if(header.length > 0) self.column[0].locked = true;
        for(var i = 0; i < header.length; i++) {
            _columns.push(self.columnTemplate(header[i]));
        }
        self.column = self.column.concat(_columns);
    }
    self.columnTemplate = function(col) {
        return {
            title: col.DisplayName,
            field: col.ComponentName,
            width: 150,
            template: function(t) {
                return "<a onclick='cellClick(\""+self.type+"\",\""+col.ComponentName+"\")' class='server-cell "+t[col.ComponentName].type+"'>"+t[col.ComponentName].value+"</a>";
            },
            headerTemplate : "<a onclick='headerClick(\""+self.type+"\",\""+col.ComponentName+"\")'>"+col.DisplayName+"</a>",
            headerAttributes : {
                class: "server-grid"
            }
        }
    };
    self.buildGrid = function() {
        $(selector).kendoGrid({
            dataSource: {
                data: self.data,
                pageSize: 10,
            },
            scrollable: true,
            pageable: true,
            columns: self.column
        });
        self.dataGrid = $(selector).data("kendoGrid");

        if(self.column.length > 1) {
            var grid = self.dataGrid;
            var lockedContent = grid.wrapper.children(".k-grid-content-locked")
            var content = grid.wrapper.children(".k-grid-content");

            grid.wrapper.height("");
            lockedContent.height("");
            content.height("");

            grid.wrapper.height(grid.wrapper.height());

            grid.resize();
        }
        return self.dataGrid;
    }
    self.render = function() {
        self.getData({ ClusterType: self.type })
            .then(function() {
                return self.buildGrid();
            })
            .catch(function() {
                alert("failed getData");
            });
    }
}

Traffic.Grid = {
    prod: new GridServer("prod", "#gridPrd"),
    nonprod: new GridServer("nonprod", "#gridNonPrd"),
}

Traffic.Modal = {
    leftHeader: ko.observable(""),
    rightHeader: ko.observable("")
}
function headerClick(type, component) {
    ajaxPost("/nodeinfo/getdigitalpassportos", { "clustertype": type, "componentname": component}, function(res) {
        if(res.Data.length > 0) {
            Traffic.Modal.leftHeader("<p>"+res.Data[0].ClusterName+"</p><p>Last Updated: "+moment(res.Data[0].Timestamp).format("DD/MM/YYYY")+"</p>");
            Traffic.Modal.rightHeader("");
        }
        Traffic.initHeaderGrid(res.Data);
        $("#modalDetail").modal('show');
    });
}
function cellClick(type, component) {
    ajaxPost("/nodeinfo/getdigitalpassportos", { "clustertype": type, "componentname": component}, function(res) {
        if(res.Data.length > 0) {
            Traffic.Modal.leftHeader("<p>"+res.Data[0].ClusterName+"</p><p>Last Updated: "+moment(res.Data[0].Timestamp).format("DD/MM/YYYY")+"</p>");
        Traffic.Modal.rightHeader("<p>O/S: "+res.Data[0].OsName+"</p><p>Kernel: "+res.Data[0].OsKernel+"</p>");
        }
        Traffic.initHeaderGrid(res.Data);
        $("#modalDetail").modal('show');
    });
}
function serverTypeClick(host) {
    ajaxPost("/nodeinfo/getdigitalpassportbyhostip", { HostIp: host }, function(res) {
        if(res.Data.length > 0) {
            Traffic.Modal.leftHeader("<p>"+res.Data[0].ClusterName+"</p><p>Last Updated: "+moment(res.Data[0].Timestamp).format("DD/MM/YYYY")+"</p>");
            Traffic.Modal.rightHeader("");
        }
        Traffic.initHostGrid(res.Data);
        $("#modalDetail").modal('show');
    })
};

function expandDetailGrid(elem) {
    var tr = $(elem).closest("tr");
    if(tr.hasClass("expand")){
        $("#gridModal").data().kendoGrid.collapseRow(tr);
        tr.removeClass("expand");
    } else {
        $("#gridModal").data().kendoGrid.expandRow(tr);
        tr.addClass("expand");
    }
    $(".k-detail-row .k-hierarchy-cell").remove();
}
function expand(type) {
    $("."+type).css("display", "block");
    if(type == "prod") {
        $(".nonprod").css("display", "none");
        $(".prod").removeClass("split");
        $(".prod").addClass("full");
    }
    if(type == "nonprod") {
        $(".prod").css("display", "none");
        $(".nonprod").removeClass("split");
        $(".nonprod").addClass("full");
    }

    var grid = Traffic.Grid[type];
    grid.dataGrid.refresh();
    grid.dataGrid._adjustLockedHorizontalScrollBar();
    var header = $("."+type).find(".grid-type");
    header.addClass("dropdown-header");
    header.html("<input class='dropdownType' />");
    var gridType = [
        { type: "prod", title: "Production" },
        { type: "nonprod", title: "Non Production" },
    ]
    $("."+type).find(".dropdownType").kendoDropDownList({
        dataSource: {
            data: gridType
        },
        value: type,
        dataTextField: "title",
        dataValueField: "type",
        change: function() {
            expand(this._old);
        }
    })
}

Traffic.initHostGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HostIp" }
        },
        detailTemplate: "Disk Spaces: <div class='detailGrid'></div>",
        detailInit: function(e) {
            e.detailRow.find(".detailGrid").kendoGrid({
                dataSource: e.data.DiskSpace,
                columns: [
                    {title: "File System", field: "FileSystem"},
                    {title: "Mounted On", field: "MountedOn"},
                    {title: "Total", field: "Total", template: function(o) { return autoConvertKByte(o.Total) }},
                    {title: "Available", field: "Available", template: function(o) { return autoConvertKByte(o.Available) }},
                    {title: "Used", field: "Used", template: function(o) { return autoConvertKByte(o.Used) }},
                    {title: "%", field: "UsedCapacity", template: function(o) { return o.UsedCapacity.toFixed(2) + "%" }},
                ]
            })
        },
        dataBound: function() {
            $(".k-hierarchy-cell").hide();
            $(".k-hierarchy-col").remove();
        },
        sortable: true,
        columns: [
            { title: "Server", field: "HostIp" },
            { title: "CPU", field: "CpuCount", width: 80 },
            { title: "O/S", field: "OsName", width: 80 },
            { title: "Kernel", field: "OsKernel" },
            { title: "Status", field: "" },
            { title: "Storage", field: "DiskTotal", template: function(t) { return "<a onclick='expandDetailGrid(this)'>"+(t.DiskPct.toFixed(2) + "%")+"</a>"} },
            { title: "Version", field: "OsVersion" },
        ]
    })
}
Traffic.initHeaderGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HostIp" }
        },
        sortable: true,
        columns: [
            { title: "Server", field: "HostIp" },
            { title: "Version", field: "CpuCount", width: 80 },
            { title: "O/S", field: "OsName", width: 80 },
            { title: "Kernel", field: "OsKernel" },
            { title: "Status", field: "" },
        ]
    })
}
Traffic.initCellGrid = function(data) {
    $("#gridModal").html("");
    $("#gridModal").kendoGrid({
        dataSource: {
            data: data,
            sort: {field: "HostIp" }
        },
        sortable: true,
        columns: [
            { title: "Server", field: "HostIp" },
            { title: "Version", field: "CpuCount", width: 80 },
            { title: "O/S", field: "OsName", width: 80 },
            { title: "Kernel", field: "OsKernel" },
            { title: "Status", field: "" },
        ]
    })
}

Traffic.generateProductionGrid = function() {
    Traffic.Grid.prod.render();
}
Traffic.generateNonProductionGrid = function() {
    Traffic.Grid.nonprod.render();
}

Traffic.init = function() {
    this.generateNonProductionGrid();
    this.generateProductionGrid();
}

$(function() {
    Traffic.init();
})