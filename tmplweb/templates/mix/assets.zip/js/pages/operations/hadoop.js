var OPHadoop = {};
OPHadoop.OpcData = ko.observableArray([]);
OPHadoop.Modal = {
    title: ko.observable(""),
    selector: "#modalDetail",
    additional : {
        memory: function(additional) {
            var series = additional.series;
            var pct = 0;
            if(series.length > 0) pct = parseFloat(series[series.length - 1].Val) / parseFloat(additional.max) * 100;
            var html = '<div class="opProgress text-center"><div class="bar default" style="width: '+pct+'%"></div></div>';
            return html;
        }
    }
}

function b2kb(b){
    return (b / (1024)).toFixed(2);
}

OPHadoop.RangedModal = {
    title: ko.observable(""),
    selector: "#clusterModal",
    data: {
        id: ko.observable(""),
        endDate: ko.observable(""),
        startDate: ko.observable(""),
    },
    charts: {
        storage: ko.observable(),
        io: ko.observable(),
        memory: ko.observable(),
        cpu: ko.observable(),
    }
}
OPHadoop.RangedModal.data.startDate.subscribe(function(val) {
  var id = OPHadoop.RangedModal.data.id();
  var startDate = OPHadoop.RangedModal.data.startDate();
  var endDate = OPHadoop.RangedModal.data.endDate();
  OPHadoop.renderRangedChart(id, startDate, endDate)
})

function DetailGrid(id, name, type) {
    var columnGrid = {
        storage: function(data){
            var totalLabel = averagedStorageLabel(_.map(data, function(o){ return o.DiskTotal}))
            var usageLabel = averagedStorageLabel(_.map(data, function(o){ return o.DiskUsage}))
            var availableLabel = averagedStorageLabel(_.map(data, function(o){ return o.DiskFree}))
            return [
                { title: "Nodes", field: "HostName" },
                { title: "Total Storage ("+totalLabel+")", field: "DiskTotal", attributes:{ class: "text-right" }, template: function(o) { return convertGig(o.DiskTotal, totalLabel) } },
                { title: "Usage Storage ("+usageLabel+")", field: "DiskUsage", attributes:{ class: "text-right" }, template: function(o) { return convertGig(o.DiskUsage, usageLabel) } },
                { title: "Available Storage ("+availableLabel+")", field: "DiskFree", attributes:{ class: "text-right" }, template: function(o) { return convertGig(o.DiskFree, availableLabel) } },
                { title: "Used Storage (%)", field: "DiskPct", attributes:{ class: "text-right", style: "position: relative" }, template: function(o) { return "<a class='server-cell-full "+getType(o.DiskPct)+"'>"+o.DiskPct.toFixed(2)+"</a>" } },
            ]
        },
        io: function() {
          return [
            { title: "Nodes", field: "HostName" },
            { title: "Bytes In", field: "NetworkInfo.AvgIn", template: function(d) { return b2kb(d.NetworkInfo.AvgIn) + " KB"}},
            { title: "Bytes Out", field: "NetworkInfo.AvgOut", template: function(d) { return b2kb(d.NetworkInfo.AvgOut) + " KB"}},
            { title: "Process Run", field: "IOinfo.TotalProcess", attributes: { class: "text-right" } }
          ]
        },
        cpu: function() {
          return [
            { title: "Nodes", field: "HostName" },
            { title: "CPU Used", field: "CPU.Current", attributes:{ class: "text-right"} },
            { title: "CPU Available", field: "CPU.Current", attributes:{ class: "text-right"}, template: function(d) { return 100 - d.CPU.Current } },
            { title: "CPU Used (%)", field: "CPU.Current", attributes: {class: "text-right", style: "position: relative" }, template: function(o) { return "<a class='server-cell-full "+getType(o.CPU.Current)+"'>"+o.CPU.Current.toFixed(2)+"</a>" }}
          ]
        },
        memory: function(){
            return [
                { title: "Nodes", field: "HostName", width: 150 },
                { title: "Total Memory (GB)", field: "MemTotal", attributes:{ class: "text-right" }, template: function(o) {return kb2gb(o.MemTotal)} },
                { title: "Used (GB)", field: "MemUsed", attributes:{ class: "text-right" }, template: function(o) {return kb2gb(o.MemUsed)} },
                { title: "Available (GB)", field: "MemFree", attributes:{ class: "text-right" }, template: function(o) {return kb2gb(o.MemFree)} },
                { title: "Used Memory (%)", field: "MemPct", attributes:{ class: "text-right", style: "position: relative" }, template: function(o) {return "<a class='server-cell-full "+getType(o.MemPct)+"'>"+o.MemPct.toFixed(2)+"</a>"} },
                {
                    title: "Aging of Running Jobs",
                    columns: [
                        { title: "> 60 mins", field: "" },
                        { title: "30 - 60 mins", field: "" },
                        { title: "15 - 30 mins", field: "" },
                        { title: "< 15 mins", field: "" },
                    ]
                }
            ]
        }
    }
    var self = this;
    self.selector = "#gridModal";
    self.render = function() {
        return new Promise(function(res, rej) {
            ajaxPost("/nodeinfo/statusinfo", { ClusterId: id }, function(r){
                $(self.selector).html("");
                $(self.selector).kendoGrid({
                    dataSource: {
                        data: r.Data,
                        pageSize: 10,
                    },
                    selectable: "row",
                    change: function(e) {
                        var grid = e.sender;
                        var data = grid.dataItem(this.select());
                        redirectUrl("/opchadoop/details?id="+data.ClusterId+"&node="+data.HostName+"&fetch="+data.FetchNumber+"&name="+data.ClusterName+"&ip="+data.HostIp);
                    },
                    pageable: true,
                    columns: columnGrid[type](r.Data)
                });
                res(r);
            }, function(){
                rej("Failed");
            })
        });
    }
}

function OpcBarChart(name, id, data) {
    var self = this;
    self.pct = ko.observable(0);
    self.diskUsedInf = ko.observable("");
    self.diskFree = ko.observable("");
    self.type = ko.observable("");

    self.render = function() {
        var pct = (data.Pct * 100).toFixed(2);
        var free = data.Free.toFixed(2);
        var used = data.Used.toFixed(2);
        if(pct > 85) self.type("bar red");
        else if(pct > 70) self.type("bar yellow");
        else self.type("bar green");
        self.pct(pct);
        self.diskUsedInf(used+data.Label+" ("+pct+"%)");
        self.diskFree(+free+data.Label+" ("+(100 - pct)+"%)");
    }
}

function OpcAreaChart(name, id, data) {
    var self = this;
    self.process = ko.observable("");
    self.selector = "#opChartArea-"+id
    self.label = "";

    self.formatData = function(data) {
        var newFormat = [];
        var colors = ["rgb(0, 117, 176)", "rgb(106, 193, 123)"];
        newFormat.push({
            name: "Read Throughput",
            data: ascSortByTs(data.IO0),
            color: colors[0]
        });
        newFormat.push({
            name: "Write Throughput",
            data: ascSortByTs(data.IO1),
            color: colors[1]
        });
        return newFormat;
    }
    self.formatCategories = function(data) {
        return _.map(data, function(d) {
            var date = new Date(0);
            date.setUTCSeconds(d.Ts);
            return moment(date).format("HH:mm");
        })
    }
    self.render = function() {
        self.process("Current: "+data.Process+" processes");

        var series = self.formatData(data.Data);
        var selector = $(self.selector).find(".area");
        var categories = self.formatCategories(series[1].data);
        self.label = averagedLabel(_.map(series[1].data, function(d) {return d.Val}));
        selector.html("");
        if(categories.length > 0)
        selector.kendoSparkline({
            seriesDefaults: {
                type: "line",
                field: "Val",
                style: "smooth",
            },
            chartArea: {
                height: 125
            },
            categoryAxis: {
                visible: true,
                categories: categories,
                majorTicks: {
                    step: categories.length - 1,
                },
                line: {
                    visible: true,
                },
                labels: {
                    step: categories.length - 1,
                    font: "10px Arial,Helvetica,sans-serif"
                }
            },
            series: series,
            tooltip: {
                background: "rgba(65,65,65,.6)",
                template: function(o) {
                    var data = o.dataItem;
                    var d = new Date(0);
                    d.setUTCSeconds(data.Ts);
                    return convertByte(data.Val, self.label)+" "+self.label+" at "+moment(d).format("HH:mm:ss");
                }
            },
        })
    }
}

function OpcLineChart(name, id ,data) {
    var self = this;
    self.maxInf = ko.observable("");
    self.max = 0;
    self.selector = "#opChartLine-"+id;
    self.series = null;

    self.formatData = function(data) {
        return _.map(data, function(d) {
            return {
                Val: (d.Val / 1048576).toFixed(2),
                Ts: d.Ts,
                Tst: d.Tst
            }
        })
    }
    self.formatCategories = function(data) {
        return _.map(data, function(d) {
            var date = new Date(0);
            date.setUTCSeconds(d.Ts);
            return moment(date).format("HH:mm");
        })
    }

    self.render = function() {
        var max = (data.Max / 1048576).toFixed(2);
        self.max = max;
        self.maxInf("Max: "+max+"GB");
        var selector = $(self.selector).find(".line");
        var timeline = ascSortByTs(data.Timeline);
        var categories= self.formatCategories(timeline);
        selector.html("");
        self.series = self.formatData(timeline);
        var dataPeak = _.maxBy(self.series, function(o) { return o.Val });
        if(self.series.length > 0)
            selector.kendoSparkline({
                data: self.series,
                // plotAreaClick: function() {
                //     OPHadoop.handleChartClick(id, name, "memory", { series: self.series});
                // },
                seriesDefaults: {
                    type: "line",
                    line: {
                        width: 2
                    },
                    field: "Val",
                    color: "rgb(40, 144, 192)"
                },
                chartArea: {
                    height: 125,
                },
                valueAxis:{
                    visible: true,
                    majorUnit: Math.round((parseFloat(dataPeak.Val) / 3) * 100) / 100,
                    plotBands: [
                        {
                            from: max,
                            to: max + 2,
                            color: "#000",
                        }
                    ],
                    labels:{
                        visible: true,
                        font: "10px Arial,Helvetica,sans-serif"
                    }
                },
                categoryAxis: {
                    visible: true,
                    categories: categories,
                    majorTicks: {
                        step: categories.length - 1,
                    },
                    line: {
                        visible: true,
                    },
                    labels: {
                        step: categories.length - 1,
                        font: "10px Arial,Helvetica,sans-serif"
                    }
                },
                tooltip: {
                    background: "rgba(65,65,65,.6)",
                    template: function(o) {
                        var data = o.dataItem;
                        var d = new Date(0);
                        d.setUTCSeconds(data.Ts);
                        return data.Val+"GB at "+moment(d).format("HH:mm:ss");
                    }
                },
            })
    }
}

function OpcCircleChart(name, id, data) {
    var self = this;
    self.selector = "#opChartCircle-"+id;

    self.getCircleChart = function(pct) {
        return '<svg class="circle-chart" viewbox="0 0 33.83098862 33.83098862" width="150" height="150" xmlns="http://www.w3.org/2000/svg"><circle class="circle-chart__background" stroke="rgb(195, 226, 193)" stroke-width="2" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><circle class="circle-chart__circle" stroke="rgb(63, 156, 53)" stroke-width="2" stroke-dasharray="'+pct+',100" stroke-linecap="round" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><g class="circle-chart__info"><text class="circle-chart__percent" x="16.91549431" y="16" alignment-baseline="central" text-anchor="middle" fill="rgb(106, 193, 123)" font-size="6">'+pct+'%</text></g></svg>';
    }
    self.render = function() {
        var html = self.getCircleChart(data.Current.toFixed(2));
        $(self.selector).html(html);
    }
}


function RangedOpcLineChart(selector, data) {
    var self = this;
    self.selector = selector;
    self.series = null;

    self.formatData = function(data) {
        return _.map(data, function(d) {
            return {
                Val: (d.Val / 1048576).toFixed(2),
                Ts: d.Ts,
                Tst: d.Tst
            }
        })
    }
    self.formatCategories = function(data) {
        return _.map(data, function(d) {
            var date = new Date(0);
            date.setUTCSeconds(d.Ts);
            return moment(date).format("HH:mm");
        })
    }

    self.render = function() {
        var selector = $(self.selector).find(".line");
        selector.html("");
        var timeline = ascSortByTs(data.Timeline);
        var categories= self.formatCategories(timeline);
        self.series = self.formatData(timeline);
        var dataPeak = _.maxBy(self.series, function(o) { return o.Val });
        if(self.series.length > 0)
            selector.kendoChart({
              series: [
                {
                  data: self.series,
                  markers: {
                      visible: false,
                  },
                }
              ],
                seriesDefaults: {
                    type: "line",
                    line: {
                        width: 2
                    },
                    field: "Val",
                    color: "rgb(40, 144, 192)"
                },
                chartArea: {
                    height: 125,
                },
                valueAxis:{
                    visible: true,
                    majorGridLines: {
                      visible: false
                    },
                    majorUnit: Math.round((parseFloat(dataPeak.Val) / 3) * 100) / 100,
                    labels:{
                        visible: true,
                        font: "10px Arial,Helvetica,sans-serif"
                    }
                },
                categoryAxis: {
                    visible: true,
                    categories: categories,
                    majorGridLines: {
                      visible: false
                    },
                    majorTicks: {
                        step: categories.length - 1,
                    },
                    line: {
                        visible: true,
                    },
                    labels: {
                        step: categories.length - 1,
                        font: "10px Arial,Helvetica,sans-serif"
                    },
                    crosshair: {
                        visible: true
                    }
                },
                tooltip: {
                    visible: true,
                    background: "rgba(65,65,65,.6)",
                    template: function(o) {
                        var data = o.dataItem;
                        var d = new Date(0);
                        d.setUTCSeconds(data.Ts);
                        return data.Val+"GB at "+moment(d).format("MM-DD-YYYY HH:mm:ss");
                    }
                },
            })
    }
}
function RangedOpcIOChart(selector, data) {
    var self = this;
    self.selector = selector
    self.label = "";

    self.convert = function(data) {
      return _.map(data, function(d) {
        return {
          Ts: d.Ts,
          Val: convertByte(d.Val, self.label)
        };
      })
    }
    self.formatData = function(data) {
        var newFormat = [];
        var colors = ["rgb(0, 117, 176)", "rgb(106, 193, 123)"];
        newFormat.push({
            name: "Read Throughput",
            data: self.convert(ascSortByTs(data.IO0)),
            color: colors[0],
            markers: {
                visible: false,
            },
        });
        newFormat.push({
            name: "Write Throughput",
            data: self.convert(ascSortByTs(data.IO1)),
            color: colors[1],
            markers: {
                visible: false,
            },
        });
        return newFormat;
    }
    self.formatCategories = function(data) {
        return _.map(data, function(d) {
            var date = new Date(0);
            date.setUTCSeconds(d.Ts);
            return moment(date).format("HH:mm");
        })
    }
    self.render = function() {

        self.label = averagedLabel(_.map(data.Data.IO1, function(d) {return d.Val}));
        var series = self.formatData(data.Data);
        var io0 = _.maxBy(series[0].data, function(d) {return d.Val});
        var io1 = _.maxBy(series[1].data, function(d) {return d.Val});
        var dataPeak = _.max([io0 ? io0.Val : 0, io1 ? io1.Val :0]);
        var selector = $(self.selector).find(".area");
        var categories = self.formatCategories(series[1].data);
        selector.html("");
        selector.kendoChart({
            seriesDefaults: {
                type: "line",
                field: "Val",
                line: {
                    width: 2
                },
                style: "smooth",
            },
            chartArea: {
                height: 125
            },
            categoryAxis: {
                visible: true,
                categories: categories,
                majorTicks: {
                    step: categories.length - 1,
                },
                majorGridLines: {
                  visible: false
                },
                line: {
                    visible: true,
                },
                labels: {
                    step: categories.length - 1,
                    font: "10px Arial,Helvetica,sans-serif"
                },
                crosshair: {
                    visible: true
                }
            },
            valueAxis: {
              majorUnit: Math.round((parseFloat(dataPeak) / 3) * 100) / 100,
              majorGridLines: {
                visible: false
              },
            },
            series: series,
            tooltip: {
                visible: true,
                shared: true,
                background: "rgba(65,65,65,.6)",
                template: function(o) {
                    var data = o.dataItem;
                    var d = new Date(0);
                    d.setUTCSeconds(data.Ts);
                    return data.Val+" "+self.label+" at "+moment(d).format("MM-DD-YYYY HH:mm");
                }
            },
        })
    }
}

OPHadoop.getData = function() {
    return new Promise(function(res, rej) {
        ajaxPost("/opchadoop/getclusterstatus",{}, function(r) {
            res(r.Data);
            
        }, function() {
            rej("Failed get data");
        })
    });
}
OPHadoop.getRangedData = function(id, startDate, endDate) {
    return new Promise(function(res, rej) {
      var payload = { ClusterId: id };
      if(startDate) {
        payload.TimeStart = startDate;
        payload.TimeEnd = endDate;
      }
        ajaxPost("/opchadoop/getclusterdetail",payload, function(r) {
            res(r);
        }, function() {
            rej("Failed get data");
        })
    });
}
OPHadoop.buildData = function(data) {
    var newFormat = [];
    for(var i = 0; i < data.length; i++) {
        var d = data[i];
        newFormat.push({
            name: d.ClusterName,
            id: d.ClusterId,
            storage: new OpcBarChart(d.ClusterName, d.ClusterId, d.Storage),
            io: new OpcAreaChart(d.ClusterName, d.ClusterId, d.IOinfo),
            memory: new OpcLineChart(d.ClusterName, d.ClusterId, d.Memory),
            cpu: new OpcCircleChart(d.ClusterName, d.ClusterId, d.CPU),
        })
    }
    return newFormat;
}
OPHadoop.handleOpClick = function(e, id, name) {
    OPHadoop.renderRanged(id, name);
    var modal = $("#clusterModal");
    var opcId = $(e.currentTarget).parent().attr("id").substr(4);
    for(var i = 0; i < parseInt(opcId, 10); i++) {
        $("#opc-"+i).css("display", "none");
    }
    modal.find(".modal-dialog").css("left", (e.currentTarget.offsetLeft+230)+"px");
    modal.modal("show");
}

OPHadoop.handleChartClick = function(id, name, type, additional) {
    var grid = new DetailGrid(id, name, type);
    grid.render()
        .then(function() {
            OPHadoop.Modal.title(capitalize(type) +" | "+ name);
            $(OPHadoop.Modal.selector).find(".additional").html("");
            if(additional) {
                $(OPHadoop.Modal.selector).find(".additional").html(OPHadoop.Modal.additional[type](additional));
            }
            $(OPHadoop.Modal.selector).modal("show");
        })
        .catch(function(msg) {
            alert(msg);
        });
}

OPHadoop.render = function(interval) {
    OPHadoop.getData()
    .then(function(data) {
        var newData = OPHadoop.buildData(data);
        OPHadoop.OpcData(newData);
    })
    .then(function() {
        var data = OPHadoop.OpcData();
        _.each(data, function(d) {
            d.storage.render();
            d.io.render();
            d.memory.render();
            d.cpu.render();
        })
    })
    .catch(function(msg) {
        if(interval) clearInterval(interval);
        alert(msg);
    })
}

OPHadoop.renderRanged = function(id, title) {
    var modal = OPHadoop.RangedModal;
    modal.title("Ranged Detail for "+title);
    OPHadoop.RangedModal.data.id(id);
    OPHadoop.renderRangedChart(id);
}

OPHadoop.renderRangedChart = function(id, startDate, endDate) {
  OPHadoop.getRangedData(id, startDate, endDate)
          .then(function(data) {
            var modal = OPHadoop.RangedModal;
            modal.charts.storage = new RangedOpcLineChart(".rangedStorage", data.Storage);
            modal.charts.io = new RangedOpcIOChart(".rangedIO", data.IOinfo);
            modal.charts.memory = new RangedOpcLineChart(".rangedMemory", data.Memory);
            modal.charts.cpu = new RangedOpcLineChart(".rangedCpu", data.CPU);

            modal.charts.storage.render();
            modal.charts.io.render();
            modal.charts.memory.render();
            modal.charts.cpu.render();
          });
}

OPHadoop.init = function() {
    OPHadoop.render();
    // var interval = setInterval(function() {
    //     OPHadoop.render(interval);
    // }, 60000);
}

$(function() {
    OPHadoop.init();
    $("#clusterModal").on("hide.bs.modal", function(e) {
        for(var i = 0; i < OPHadoop.OpcData().length; i++) {
            $("#opc-"+i).css("display", "block");
        }
    });
    var today = new Date();
    $("input[name='daterange']").daterangepicker({
        "alwaysShowCalendars": true,
        "timePicker": true,
        "timePicker24Hour": true,
        "locale": {
            "format": "MM/DD/YYYY HH:mm"
        },
        "ranges": {
            "1 Hour": [moment().subtract(1, "hours").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Day": [moment().subtract(1, "days").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Week": [moment().subtract(1, "weeks").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Month": [moment().subtract(1, "months").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
        }
    }, function(start, end) {
        OPHadoop.RangedModal.data.endDate(end.format("YYYYMMDDHHmmss"))
        OPHadoop.RangedModal.data.startDate(start.format("YYYYMMDDHHmmss"))
    });
})