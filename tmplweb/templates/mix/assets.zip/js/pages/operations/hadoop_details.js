function b2kb(b){
  return (b / (1024)).toFixed(2);
}

function CPUChart(selector, data) {
  var self = this;
  self.getCircleChart = function(pct) {
      return '<svg class="circle-chart" viewbox="0 0 33.83098862 33.83098862" width="150" height="150" xmlns="http://www.w3.org/2000/svg"><circle class="circle-chart__background" stroke="rgb(195, 226, 193)" stroke-width="2" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><circle class="circle-chart__circle" stroke="rgb(63, 156, 53)" stroke-width="2" stroke-dasharray="'+pct+',100" stroke-linecap="round" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><g class="circle-chart__info"><text class="circle-chart__percent" x="16.91549431" y="16" alignment-baseline="central" text-anchor="middle" fill="rgb(106, 193, 123)" font-size="6">'+pct+'%</text></g></svg>';
  }
  self.render = function() {
      var html = self.getCircleChart(data.Current.toFixed(2));
      $(selector).html(html);
  }
}

function CPUTimelineChart(selector, data) {
  var self = this;
  self.selector = selector;
  self.series = null;

  self.formatData = function(data) {
      return _.map(data, function(d) {
          return {
              Val: parseFloat((d.Val).toFixed(2)),
              Ts: d.Ts,
          }
      })
  }

  self.formatCategories = function(data) {
      return _.map(data, function(d) {
          var date = new Date(0);
          date.setUTCSeconds(d.Ts);
          return moment(date).format("HH:mm");
      })
  }

  self.render = function() {
      var selector = $(self.selector);
      var timeline = ascSortByTs(data.Timeline);
      var categories= self.formatCategories(timeline);
      self.series = self.formatData(timeline);
      var dataPeak = _.maxBy(self.series, function(o) { return o.Val });
      selector.html("");
      if(self.series.length > 0)
          selector.kendoChart({
              series: [
                  {
                      data: self.series,
                      markers: {
                          visible: false,
                      },
                      style: "smooth"
                  }
              ],
              axisDefaults: {
                  majorGridLines: {
                      visible: false
                  }
              },
              seriesDefaults: {
                  type: "line",
                  line: {
                      width: 2
                  },
                  field: "Val",
                  color: "rgb(40, 144, 192)"
              },
              chartArea: {
                  height: 155,
              },
              valueAxis:{
                  visible: true,
                  majorUnit: Math.round((dataPeak.Val / 3) * 100) / 100,
                  labels:{
                      visible: true,
                  }
              },
              categoryAxis: {
                  visible: true,
                  categories: categories,
                  crosshair: {
                      visible: true,
                  },
                  majorTicks: {
                      step: categories.length - 1,
                  },
                  line: {
                      visible: true,
                  },
                  labels: {
                      step: categories.length - 1,
                  }
              },
              tooltip: {
                  visible: true,
                  background: "rgba(65,65,65,.6)",
                  template: function(o) {
                      var data = o.dataItem;
                      var d = new Date(0);
                      d.setUTCSeconds(data.Ts);
                      return data.Val+"% at "+moment(d).format("HH:mm:ss");
                  }
              },
          })
  }
}

function StorageChart(selector, data) {
  var self = this;
  self.pct = ko.observable(0);
  self.diskUsedInf = ko.observable("");
  self.diskFree = ko.observable("");
  self.type = ko.observable("");

  self.render = function() {
      var pct = data.DiskPct.toFixed(2);
      var free = data.DiskFree.toFixed(2);
      var used = data.DiskUsage.toFixed(2);
      if(pct > 85) self.type("bar red");
      else if(pct > 70) self.type("bar yellow");
      else self.type("bar green");
      self.pct(pct);
      self.diskUsedInf(used+" GB"+" ("+pct+"%)");
      self.diskFree(free+" GB"+" ("+(100 - pct)+"%)");
  }
}

function StorageTimelineChart(selector, data) {
  var self = this;
  self.selector = selector;
  self.series = null;

  self.formatData = function(data) {
      return _.map(data, function(d) {
          return {
              Val: parseFloat((d.Val).toFixed(2)),
              Ts: d.Ts,
          }
      })
  }

  self.formatCategories = function(data) {
      return _.map(data, function(d) {
          var date = new Date(0);
          date.setUTCSeconds(d.Ts);
          return moment(date).format("HH:mm");
      })
  }

  self.render = function() {
      var selector = $(self.selector);
      var timelineFree = ascSortByTs(data.DiskFree);
      var timelineTotal = ascSortByTs(data.DiskTotal);
      var peakFree = _.maxBy(timelineFree, function(d) {return d.Val });
      var peakTotal = _.maxBy(timelineTotal, function(d) {return d.Val });
      var dataPeak = _.max([peakFree ? peakFree.Val : 0, peakTotal ? peakTotal.Val : 0]);
      var categories= self.formatCategories(timelineFree);
      console.log(data);
      self.series = [
        {
          data: timelineFree,
          field: "Val",
          name: "Disk Free",
          color: "rgb(0, 117, 176)"
        },
        {
          data: timelineTotal,
          field: "Val",
          name: "Disk Used",
          color: "rgb(106, 193, 123)"
        }
      ];
      var dataPeak = _.maxBy(self.series, function(o) { return o.Val });
      selector.html("");

      if(self.series.length > 0)
          selector.kendoChart({
              series: self.series,
              axisDefaults: {
                  majorGridLines: {
                      visible: false
                  }
              },
              seriesDefaults: {
                  type: "line",
                  line: {
                      width: 2
                  },
                  markers: {
                    visible: false,
                  },
                  style: "smooth",
                  field: "Val",
                  color: "rgb(40, 144, 192)"
              },
              chartArea: {
                  height: 155,
              },
              valueAxis:{
                  visible: true,
                  majorUnit: Math.round(((dataPeak? dataPeak.Val : 0) / 3) * 100) / 100,
                  labels:{
                      visible: true,
                  }
              },
              
              legend: {
                visible: true,
                position: "bottom",
                background: "rgba(0,0,0,.6)",
                labels: {
                  color: "#FFFFFF"
                }
              },
              categoryAxis: {
                  visible: true,
                  categories: categories,
                  crosshair: {
                      visible: true,
                  },
                  majorTicks: {
                      step: categories.length - 1,
                  },
                  line: {
                      visible: true,
                  },
                  labels: {
                      step: categories.length - 1,
                  }
              },
              tooltip: {
                  visible: true,
                  background: "rgba(65,65,65,.6)",
                  shared: true,
                  template: function(o) {
                      var data = o.dataItem;
                      var d = new Date(0);
                      d.setUTCSeconds(data.Ts);
                      return data.Val+"GB at "+moment(d).format("HH:mm:ss");
                  }
              },
          })
  }
}

function MemoryChart(selector, data) {
  var self = this;

  self.maxInf = ko.observable("");
  self.max = 0;
  self.selector = selector;
  self.series = null;

  self.formatData = function(data) {
      return _.map(data, function(d) {
          return {
              Val: parseFloat((d.Val / 1048576).toFixed(2)),
              Ts: d.Ts,
          }
      })
  }

  self.formatCategories = function(data) {
      return _.map(data, function(d) {
          var date = new Date(0);
          date.setUTCSeconds(d.Ts);
          return moment(date).format("HH:mm");
      })
  }

  self.render = function() {
      var max = (data.Max / 1048576).toFixed(2);
      var selector = $(self.selector);

      self.max = max;
      self.maxInf("Max: "+max+"GB");
      var timeline = ascSortByTs(data.Timeline);
      var categories= self.formatCategories(timeline);
      self.series = self.formatData(timeline);
      var dataPeak = _.maxBy(self.series, function(o) { return o.Val });
      selector.html("");

      if(self.series.length > 0)
          selector.kendoChart({
              series: [
                  {
                      data: self.series,
                      markers: {
                          visible: false,
                      },
                      style: "smooth"
                  }
              ],
              axisDefaults: {
                  majorGridLines: {
                      visible: false
                  }
              },
              seriesDefaults: {
                  type: "line",
                  line: {
                      width: 2
                  },
                  field: "Val",
                  color: "rgb(40, 144, 192)"
              },
              chartArea: {
                  height: 155,
              },
              valueAxis:{
                  visible: true,
                  majorUnit: Math.round((dataPeak.Val / 3) * 100) / 100,
                  plotBands: [
                      {
                          from: max,
                          to: max + 2,
                          color: "#000",
                      }
                  ],
                  labels:{
                      visible: true,
                  }
              },
              categoryAxis: {
                  visible: true,
                  categories: categories,
                  crosshair: {
                      visible: true,
                  },
                  majorTicks: {
                      step: categories.length - 1,
                  },
                  line: {
                      visible: true,
                  },
                  labels: {
                      step: categories.length - 1,
                  }
              },
              tooltip: {
                  visible: true,
                  background: "rgba(65,65,65,.6)",
                  template: function(o) {
                      var data = o.dataItem;
                      var d = new Date(0);
                      d.setUTCSeconds(data.Ts);
                      return data.Val+"GB at "+moment(d).format("HH:mm:ss");
                  }
              },
          })
  }
}

function NetworkChart(selector, data) {
  var self = this;
  self.selector = selector;
  self.formatData = function(data) {
    return _.map(data, function(d) {
      return parseFloat(b2kb(d.Val))
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      var date = new Date(0);
      date.setUTCSeconds(d.Ts);
      return moment(date).format("HH:mm");
    })
  }
  self.render = function() {
      var selector = $(self.selector);
      var netin = ascSortByTs(data.Data.NetIn);
      var netout = ascSortByTs(data.Data.NetOut);
      var inSeries = self.formatData(netin);
      var outSeries = self.formatData(netout);
      var categories = self.formatCategories(netin);
      var inDataPeak = _.max(inSeries);
      var outDataPeak = _.max(outSeries);
      var dataPeak = _.max([inDataPeak, outDataPeak]);
      selector.html("");
      selector.kendoChart({
        seriesDefaults: {
          type: "column",
          overlay: {
            gradient: "none"
          }
        },
        series: [
          {
            name: "Bytes In",
            data: inSeries,
            color: "rgb(63, 156, 53)"
          },
          {
            name: "Bytes Out",
            data: outSeries,
            color: "rgb(0, 92, 132)"
          }
        ],
        categoryAxis: {
          visible: true,
          categories: categories,
          majorGridLines: {
            visible: false
          },
          majorTicks: {
              step: categories.length - 1,
          },
          line: {
              visible: true,
          },
          labels: {
              step: categories.length - 1,
          }
        },
        legend: {
          visible: true,
          position: "custom",
          offsetX: 420,
          background: "rgba(0,0,0,.6)",
          labels: {
            color: "#FFFFFF"
          }
        },
        valueAxis:{
          visible: true,
          majorUnit: Math.round((parseFloat(dataPeak) / 3) * 100) / 100,
          labels:{
              visible: true,
              template: "#= value # Kb"
          }
        },
        pannable:{
          lock: "y"
        },
        zoomable: {
          mousewheel: {
            lock: "y"
          },
          selection: {
            lock: "y"
          }
        }
      })
  }
}

function IOChart(selector, data) {
  var self = this;
  self.selector = selector;

  self.formatData = function(data) {
    return _.map(data, function(d) {
      return d.Val
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      var date = new Date(0);
      date.setUTCSeconds(d.Ts);
      return moment(date).format("HH:mm");
    })
  }
  self.render = function() {
      var selector = $(self.selector);
      var _io0 = ascSortByTs(data.Data.IO0);
      var _io1 = ascSortByTs(data.Data.IO1);
      var IO0 = self.formatData(_io0);
      var IO1 = self.formatData(_io1);
      var categories = self.formatCategories(_io0);
      selector.html("");
      selector.kendoChart({
        seriesDefaults: {
          type: "area",
        },
        series: [
          {
            name: "Process Run",
            data: IO0,
            color: "rgb(63, 156, 53)"
          },
          {
            name: "Total Process",
            data: IO1,
            color: "rgb(0, 92, 132)"
          }
        ],
        legend: {
          visible: true,
          position: "custom",
          offsetX: 400,
          background: "rgba(0,0,0,.6)",
          labels: {
            color: "#FFFFFF"
          }
        },
        categoryAxis: {
          visible: true,
          categories: categories,
          majorGridLines: {
            visible: false
          },
          crosshair: {
            visible: true
          },
          majorTicks: {
              step: categories.length - 1,
          },
          line: {
              visible: true,
          },
          labels: {
              step: categories.length - 1,
          }
        },
        tooltip: {
          visible: true,
          background: "rgba(65,65,65,.6)",
          shared: true,
        },
      })
  }
}

function CpuTopChart(selector, data) {
  var self = this;
  self.selector = selector;

  self.formatData = function(data) {
    return _.map(data, function(d) {
      return {
        value: parseFloat(d.CPUUsage).toFixed(2),
        colorVal: getTypeColor(d.CPUUsage),
        cpu: d.CpuTop
      };
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      return moment(d.Timestamp).format("DD/MM/YYYY");
    })
  }
  self.renderTableTooltip = function(data) {
    var html = "";
    html += "<table cellpadding='3' class='table-tooltip'>";
    html += "<thead><tr><th>PID</th><th>CPU(%)</th><th>CMD</th><th>User</th></tr></thead>";
    html += "<tbody>";
    _.each(data, function(d) {
      html += "<tr><td class='text-center'><div>"+d.PID+"</div></td><td class='text-center'><div>"+d.CPU+"</div></td><td class='text-center'><div>"+d.Command+"</div></td><td class='text-center'><div>"+d.User+"</div></td></tr>";
    })
    html += "</tbody>";
    html += "</table>";
    return html;
  }
  self.render = function() {
    var selector = $(self.selector);
    selector.html("");
    var series = self.formatData(data);
    var categories = self.formatCategories(data);
    var dataPeak = _.maxBy(series, function(d) {return d.value});
    selector.kendoChart({
      seriesDefaults: {
        type: "column",
        overlay: {
          gradient: "none"
        }
      },
      series: [
        {
          data: series,
          colorField: "colorVal"
        },
      ],
      categoryAxis: {
        visible: true,
        categories: categories,
        majorGridLines: {
          visible: false
        },
        majorTicks: {
            step: categories.length - 1,
        },
        line: {
            visible: true,
        },
        labels: {
          visible: true,
            step: categories.length - 1,
        }
      },
      legend: {
        visible: false,
      },
      valueAxis:{
        visible: true,
        // majorUnit: Math.round((parseFloat(dataPeak) / 3) * 100) / 100,
        labels:{
            visible: true,
        }
      },

      pannable:{
        lock: "y"
      },
      zoomable: {
        mousewheel: {
          lock: "y"
        },
        selection: {
          lock: "y"
        }
      },
      axisDefaults:{
        crosshair: {
          visible: true,
          tooltip: {
            visible: true,
            background: "rgba(65,65,65,.6)"
          }
        }
      },
      tooltip: {
        visible: true,
        background: "rgb(255,255,255)",
        template: function(d) {
          return self.renderTableTooltip(d.dataItem.cpu);
        }
      }
    })
  }
}
function MemoryTopChart(selector, data) {
  var self = this;
  self.selector = selector;

  self.formatData = function(data) {
    return _.map(data, function(d) {
      return {
        value: parseFloat(d.MemPct).toFixed(2),
        colorVal: getTypeColor(d.MemPct),
        memory: d.MemTop
      };
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      return moment(d.Timestamp).format("DD/MM/YYYY");
    })
  }
  self.renderTableTooltip = function(data) {
    var html = "";
    html += "<table cellpadding='3' class='table-tooltip'>";
    html += "<thead><tr><th>PID</th><th>Mem(%)</th><th>CMD</th><th>User</th></tr></thead>";
    html += "<tbody>";
    _.each(data, function(d) {
      html += "<tr><td class='text-center'><div>"+d.PID+"</div></td><td class='text-center'><div>"+d.CPU+"</div></td><td class='text-center'><div>"+d.Command+"</div></td><td class='text-center'><div>"+d.User+"</div></td></tr>";
    })
    html += "</tbody>";
    html += "</table>";
    return html;
  }
  self.render = function() {
    var selector = $(self.selector);
    selector.html("");
    var series = self.formatData(data);
    var categories = self.formatCategories(data);
    var dataPeak = _.maxBy(series, function(d) {return d.value});
    selector.kendoChart({
      seriesDefaults: {
        type: "column",
        overlay: {
          gradient: "none"
        }
      },
      pannable:{
        lock: "y"
      },
      zoomable: {
        mousewheel: {
          lock: "y"
        },
        selection: {
          lock: "y"
        }
      },
      series: [
        {
          data: series,
          colorField: "colorVal"
        },
      ],
      categoryAxis: {
        visible: true,
        categories: categories,
        majorGridLines: {
          visible: false
        },
        majorTicks: {
            step: categories.length - 1,
        },
        line: {
            visible: true,
        },
        labels: {
            step: categories.length - 1,
        }
      },
      legend: {
        visible: false,
      },
      valueAxis:{
        visible: true,
        // majorUnit: Math.round((parseFloat(dataPeak) / 3) * 100) / 100,
        labels:{
            visible: true,
        }
      },
      axisDefaults:{
        crosshair: {
          visible: true,
          tooltip: {
            visible: true,
            background: "rgba(65,65,65,.6)"
          }
        }
      },
      tooltip: {
        visible: true,
        background: "rgb(255,255,255)",
        template: function(d) {
          return self.renderTableTooltip(d.dataItem.memory);
        }
      }
    })
  }
}

var Details = {};
Details.config = {
  url: "",
  charts: {
      cpu: ko.observable(),
      cpuTimeline: ko.observable(),
      storage: ko.observable(),
      storageTimeline: ko.observable(),
      memory: ko.observable(),
      network: ko.observable(),
      io: ko.observable(),
  },
  flip: {
    cpu: ko.observable(false),
    storage: ko.observable(false)
  },
  top: {
    visible: ko.observable(false),
    cpu: ko.observable(),
    memory: ko.observable(),
  },
  filter: {
    startDate: ko.observable(""),
    endDate: ko.observable(""),
  }
};

Details.modal = {
  selector: "#modalDetail",
  flip: {
    cpu: ko.observable(false),
    storage: ko.observable(false)
  },
  charts: {
    cpu: ko.observable(),
    cpuTimeline: ko.observable(),
    storage: ko.observable(),
    storageTimeline: ko.observable(),
    memory: ko.observable(),
    network: ko.observable(),
    io: ko.observable(),
  },
  top: {
    visible: ko.observable(false),
    cpu: ko.observable(),
    memory: ko.observable(),
  },
  filter: {
    startDate: ko.observable(""),
    endDate: ko.observable(""),
  }
}

Details.modal.filter.startDate.subscribe(function() {
  Details.initChartModal();
})
Details.renderTop = function(top, data) {
  top.cpu(new CpuTopChart("#cpuTopChart", data))
  top.memory(new MemoryTopChart("#memoryTopChart", data))
  top.cpu().render();
  top.memory().render();
  top.visible(true);
}
Details.handleTopClick = function() {
  Details.getDataTop()
         .then(function(data) {
          //  Details.renderTop(Details.config.top, data);
          Details.config.top.cpu(new CpuTopChart("#cpuTopChart", data))
          Details.config.top.memory(new MemoryTopChart("#memoryTopChart", data))
          Details.config.top.cpu().render();
          Details.config.top.memory().render();
          Details.config.top.visible(true);
           window.scrollTo(0,document.body.scrollHeight);
         })
}
Details.handleModalTopClick = function() {
  var startDate = Details.modal.filter.startDate();
  var endDate = Details.modal.filter.endDate();
  Details.getDataTop(startDate, endDate)
         .then(function(data) {
          // Details.renderTop(Details.modal.top, data);
          Details.modal.top.cpu(new CpuTopChart("#cpuTopChartModal", data))
          Details.modal.top.memory(new MemoryTopChart("#memoryTopChartModal", data))
          Details.modal.top.cpu().render();
          Details.modal.top.memory().render();
          Details.modal.top.visible(true);
           document.getElementById("modalDetail").scrollTo(0,document.getElementById("modalDetail").scrollHeight)
         })
}
Details.reloadModalTop = function() {
  var startDate = Details.modal.filter.startDate();
  var endDate = Details.modal.filter.endDate();
  Details.getDataTop(startDate, endDate)
         .then(function(data) {
            Details.renderTop(Details.modal.top, data);
           document.getElementById("modalDetail").scrollTo(0,document.getElementById("modalDetail").scrollHeight)
         })
}
Details.getData = function(startDate, endDate) {
  
  return new Promise(function(res, rej) {

      var url = window.location.href;
      var id = url.substr(url.indexOf("id")+3, url.indexOf("&node") - (url.indexOf("id")+3));
      var hostName = url.substr(url.indexOf("node")+5, url.indexOf("&fetch") - (url.indexOf("node")+5));
      var fetch = url.substr(url.indexOf("fetch")+6, url.indexOf("&name") - (url.indexOf("fetch")+6));
      var payload = { ClusterId: id, HostName: hostName, FetchNumber: fetch };
      if(startDate) {
        payload.TimeStart = startDate;
        payload.TimeEnd = endDate;
      }
      ajaxPost("/nodeinfo/getdatabynode", payload, function(r) {
        // console.log(r);
        res(r.Data[0]);
      })
  })
  
}
Details.getDataTop = function(startDate, endDate) {
  return new Promise(function(res, rej) {
    var url = window.location.href;
    var ip = url.substr(url.indexOf("&ip") + 4);
    var payload = {HostIp: ip};
    if(startDate) {
      payload.TimeStart = startDate;
      payload.TimeEnd = endDate;
    }
    ajaxPost("/nodeinfo/getnodecpumemtimeseries", payload, function(r) {
      res(r.Data);
    })
  })
}

Details.init = function() {
  var url = window.location.href;
  var hostName = url.substr(url.indexOf("node")+5, url.indexOf("&fetch") - (url.indexOf("node")+5));
  var name = url.substr(url.indexOf("name")+5, url.indexOf("&ip") - (url.indexOf("name") + 5));
  model.customBreadcrumb([decodeURI(name), decodeURI(hostName)]);
  Details.getData()
      .then(function(data) {
          var charts = Details.config.charts;
          charts.cpu(new CPUChart("#cpu", data.CPU));
          charts.cpuTimeline(new CPUTimelineChart("#cpuTimeline", data.CPU));
          charts.memory(new MemoryChart("#memory", data.Memory));
          charts.storage(new StorageChart("#storage", data));
          charts.storageTimeline(new StorageTimelineChart("#storageTimeline", data.DiskInfo));
          charts.network(new NetworkChart("#network", data.NetworkInfo));
          charts.io(new IOChart("#io", data.IOinfo));
          _.each(Object.keys(charts), function(k) {
            console.log(k);
              charts[k]().render();
          })
      })
}
Details.flip = function(type, chart) {
  Details[type].flip[chart](!Details[type].flip[chart]());
}
Details.reload = function() {
  var startDate = Details.config.filter.startDate();
  var endDate = Details.config.filter.endDate();
  Details.getData(startDate, endDate)
         .then(function(data) {
          var charts = Details.config.charts;
          charts.cpu(new CPUChart("#cpu", data.CPU));
          charts.cpuTimeline(new CPUTimelineChart("#cpuTimeline", data.CPU));
          charts.memory(new MemoryChart("#memory", data.Memory));
          charts.storage(new StorageChart("#storage", data));
          charts.storageTimeline(new StorageTimelineChart("#storageTimeline", data.DiskInfo));
          charts.network(new NetworkChart("#network", data.NetworkInfo));
          charts.io(new IOChart("#io", data.IOinfo));
          _.each(Object.keys(charts), function(k) {
              charts[k]().render();
          })
         })
}
Details.initChartModal = function() {
  var startDate = Details.modal.filter.startDate();
  var endDate = Details.modal.filter.endDate();
  Details.getData(startDate, endDate)
         .then(function(data) {
          var charts = Details.modal.charts;
          charts.cpu(new CPUChart("#cpuModal", data.CPU));
          charts.cpuTimeline(new CPUTimelineChart("#cpuTimelineModal", data.CPU));
          charts.memory(new MemoryChart("#memoryModal", data.Memory));
          charts.storage(new StorageChart("#storageModal", data));
          charts.storageTimeline(new StorageTimelineChart("#storageTimelineModal", data.DiskInfo));
          charts.network(new NetworkChart("#networkModal", data.NetworkInfo));
          charts.io(new IOChart("#ioModal", data.IOinfo));
          _.each(Object.keys(charts), function(k) {
              charts[k]().render();
          })
         })
}

$(function() {
  Details.init();
  $("input[name='daterange']").daterangepicker({
    "alwaysShowCalendars": true,
    "timePicker": true,
    "timePicker24Hour": true,
    "locale": {
        "format": "MM/DD/YYYY HH:mm"
    },
    "ranges": {
        "1 Hour": [moment().subtract(1, "hours").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
        "1 Day": [moment().subtract(1, "days").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
        "1 Week": [moment().subtract(1, "weeks").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
        "1 Month": [moment().subtract(1, "months").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
    }
}, function(start, end) {
    Details.modal.filter.endDate(end.format("YYYYMMDDHHmmss"))
    Details.modal.filter.startDate(start.format("YYYYMMDDHHmmss"))
});
})