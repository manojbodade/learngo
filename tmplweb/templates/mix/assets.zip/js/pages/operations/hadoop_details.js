function CPUChart(selector, data) {
  var self = this;
  self.getCircleChart = function(pct) {
      return '<svg class="circle-chart" viewbox="0 0 33.83098862 33.83098862" width="150" height="150" xmlns="http://www.w3.org/2000/svg"><circle class="circle-chart__background" stroke="rgb(195, 226, 193)" stroke-width="2" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><circle class="circle-chart__circle" stroke="rgb(63, 156, 53)" stroke-width="2" stroke-dasharray="'+pct+',100" stroke-linecap="round" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><g class="circle-chart__info"><text class="circle-chart__percent" x="16.91549431" y="16" alignment-baseline="central" text-anchor="middle" fill="rgb(106, 193, 123)" font-size="6">'+pct+'%</text></g></svg>';
  }
  self.render = function() {
      var html = self.getCircleChart(data.Current.toFixed(2));
      $(selector).html(html);
  }
}

function StorageChart(selector, data) {
  var self = this;
  self.pct = ko.observable(0);
  self.diskUsedInf = ko.observable("");
  self.diskFree = ko.observable("");
  self.type = ko.observable("");

  self.render = function() {
      var pct = data.DiskPct.toFixed(2);
      var free = data.DiskFree;
      var used = data.DiskUsage;
      if(pct > 85) self.type("bar red");
      else if(pct > 70) self.type("bar yellow");
      else self.type("bar green");
      self.pct(pct);
      self.diskUsedInf(used+" GB"+" ("+pct+"%)");
      self.diskFree(free+" GB"+" ("+(100 - pct)+"%)");
  }
}

function MemoryChart(selector, data) {
  var self = this;

  self.maxInf = ko.observable("");
  self.max = 0;
  self.selector = selector;
  self.series = null;

  self.formatData = function(data) {
      return _.map(data, function(d) {
          return {
              Val: (d.Val / 1048576).toFixed(2),
              Ts: d.Ts,
          }
      })
  }

  self.formatCategories = function(data) {
      return _.map(data, function(d) {
          var date = new Date(0);
          date.setUTCSeconds(d.Ts);
          return moment(date).format("HH:mm");
      })
  }

  self.render = function() {
      var max = (data.Max / 1048576).toFixed(2);
      var selector = $(self.selector);
      var categories= self.formatCategories(data.Timeline);

      self.max = max;
      self.maxInf("Max: "+max+"GB");
      self.series = self.formatData(data.Timeline);
      var dataPeak = _.maxBy(self.series, function(o) { return o.Val });

      selector.html("");

      if(self.series.length > 0)
          selector.kendoChart({
              series: [
                  {
                      data: self.series,
                      markers: {
                          visible: false,
                      },
                      style: "smooth"
                  }
              ],
              axisDefaults: {
                  majorGridLines: {
                      visible: false
                  }
              },
              seriesDefaults: {
                  type: "line",
                  line: {
                      width: 2
                  },
                  field: "Val",
                  color: "rgb(40, 144, 192)"
              },
              chartArea: {
                  height: 155,
              },
              valueAxis:{
                  visible: true,
                  majorUnit: Math.round((parseFloat(dataPeak.Val) / 3) * 100) / 100,
                  plotBands: [
                      {
                          from: max,
                          to: max + 2,
                          color: "#000",
                      }
                  ],
                  labels:{
                      visible: true,
                  }
              },
              categoryAxis: {
                  visible: true,
                  categories: categories,
                  crosshair: {
                      visible: true,
                  },
                  majorTicks: {
                      step: categories.length - 1,
                  },
                  line: {
                      visible: true,
                  },
                  labels: {
                      step: categories.length - 1,
                  }
              },
              tooltip: {
                  visible: true,
                  template: function(o) {
                      var data = o.dataItem;
                      var d = new Date(0);
                      d.setUTCSeconds(data.Ts);
                      return data.Val+"GB at "+moment(d).format("HH:mm:ss");
                  }
              },
          })
  }
}

function NetworkChart(selector, data) {
  var self = this;
  self.selector = selector;
  self.formatData = function(data) {
    return _.map(data, function(d) {
      return d.Val
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      var date = new Date(0);
      date.setUTCSeconds(d.Ts);
      return moment(date).format("HH:mm");
    })
  }
  self.render = function() {
      var selector = $(self.selector);
      var inSeries = self.formatData(data.Data.NetIn);
      var outSeries = self.formatData(data.Data.NetOut);
      var categories = self.formatCategories(data.Data.NetIn);
      var inDataPeak = _.max(inSeries);
      var outDataPeak = _.max(outSeries);
      var dataPeak = _.max([inDataPeak, outDataPeak]);
      selector.html("");
      selector.kendoChart({
        seriesDefaults: {
          type: "column",
          overlay: {
            gradient: "none"
          }
        },
        series: [
          {
            name: "Bytes In",
            data: inSeries,
            color: "rgb(63, 156, 53)"
          },
          {
            name: "Bytes Out",
            data: outSeries,
            color: "rgb(0, 92, 132)"
          }
        ],
        categoryAxis: {
          visible: true,
          categories: categories,
          majorGridLines: {
            visible: false
          },
          majorTicks: {
              step: categories.length - 1,
          },
          line: {
              visible: true,
          },
          labels: {
              step: categories.length - 1,
          }
        },
        legend: {
          visible: true,
          position: "custom",
          offsetX: 420,
          background: "rgba(0,0,0,.6)",
          labels: {
            color: "#FFFFFF"
          }
        },
        valueAxis:{
          visible: true,
          majorUnit: Math.round((parseFloat(dataPeak) / 3) * 100) / 100,
          labels:{
              visible: true,
              template: "#= value # Kb"
          }
        },
        pannable:{
          lock: "y"
        },
        zoomable: {
          mousewheel: {
            lock: "y"
          },
          selection: {
            lock: "y"
          }
        }
      })
  }
}

function IOChart(selector, data) {
  var self = this;
  self.selector = selector;

  self.formatData = function(data) {
    return _.map(data, function(d) {
      return d.Val
    })
  }
  self.formatCategories = function(data) {
    return _.map(data, function(d) {
      var date = new Date(0);
      date.setUTCSeconds(d.Ts);
      return moment(date).format("HH:mm");
    })
  }
  self.render = function() {
      var selector = $(self.selector);
      var IO0 = self.formatData(data.Data.IO0);
      var IO1 = self.formatData(data.Data.IO1);
      var categories = self.formatCategories(data.Data.IO0);
      selector.html("");
      selector.kendoChart({
        seriesDefaults: {
          type: "area",
        },
        series: [
          {
            name: "IO0",
            data: IO0,
            color: "rgb(63, 156, 53)"
          },
          {
            name: "IO1",
            data: IO1,
            color: "rgb(0, 92, 132)"
          }
        ],
        legend: {
          visible: true,
          position: "custom",
          offsetX: 420,
          background: "rgba(0,0,0,.6)",
          labels: {
            color: "#FFFFFF"
          }
        },
        categoryAxis: {
          visible: true,
          categories: categories,
          majorGridLines: {
            visible: false
          },
          crosshair: {
            visible: true
          },
          majorTicks: {
              step: categories.length - 1,
          },
          line: {
              visible: true,
          },
          labels: {
              step: categories.length - 1,
          }
        },
      })
  }
}

var Details = {};
Details.config = {
  url: "",
  charts: {
      cpu: ko.observable(),
      storage: ko.observable(),
      memory: ko.observable(),
      network: ko.observable(),
      io: ko.observable(),
  }
};

Details.getData = function() {
  
  return new Promise(function(res, rej) {
      // var url = window.location.href;
      // var id = url.substr(url.indexOf("id")+3, url.indexOf("&node") - (url.indexOf("id")+3));
      // ajaxPost("/nodeinfo/statusinfo", { ClusterId: id }, function(r) {
      //   res(r.Data[0]);
      // })

      var url = window.location.href;
      var id = url.substr(url.indexOf("id")+3, url.indexOf("&node") - (url.indexOf("id")+3));
      var hostName = url.substr(url.indexOf("node")+5, url.indexOf("&fetch") - (url.indexOf("node")+5));
      var fetch = url.substr(url.indexOf("fetch")+6);
      ajaxPost("/nodeinfo/getdatabynode", { ClusterId: id, HostName: hostName, FetchNumber: fetch }, function(r) {
        console.log(r);
        // res(r.Data[0]);
      })
  })
  
}

Details.init = function() {
  Details.getData()
      .then(function(data) {
          var charts = Details.config.charts;
          charts.cpu(new CPUChart("#cpu", data.CPU));
          charts.memory(new MemoryChart("#memory", data.Memory));
          charts.storage(new StorageChart("#storage", data));
          charts.network(new NetworkChart("#network", data.NetworkInfo));
          charts.io(new IOChart("#io", data.IOinfo));
          _.each(Object.keys(charts), function(k) {
              charts[k]().render();
          })
      })
}

$(function() {
  Details.init();
})