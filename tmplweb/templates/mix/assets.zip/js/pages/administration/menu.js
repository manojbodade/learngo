var MenuAdm = {};
MenuAdm.rawMenu = null;
MenuAdm.parent = ko.observableArray([]);
MenuAdm.treeMenu = ko.observableArray([]);
MenuAdm.selectedMenu = ko.observable();
MenuAdm.Form = {
    enabled: ko.observable(false),
    mode: ko.observable(""), // add || edit
    components: [
        {
            Id: "Parent",
            Title: "Parent",
            Enabled: false,
            Mandatory: true,
            Data: ko.observableArray([]),
            Value: ko.observable(),
            Type: "dropdown",
        },
        {
            Id: "Title",
            Title: "Title",
            Mandatory: true,
            Enabled: false,
            Value: ko.observable(),
            Type: "text",
        },
        {
            Id: "Url",
            Title: "Url",
            Mandatory: true,
            Enabled: false,
            Value: ko.observable(),
            Type: "text",
        },
        {
            Id: "Icon",
            Title: "Icon",
            Mandatory: true,
            Enabled: false,
            Value: ko.observable(),
            Type: "text",
        },
        {
            Id: "IndexMenu",
            Title: "Index",
            Mandatory: true,
            Enabled: false,
            Value: ko.observable(),
            Type: "number",
        },
        {
            Id: "Enable",
            Title: "Enable",
            Mandatory: true,
            Data: ["ON", "OFF"],
            Enabled: false,
            Value: ko.observable(true),
            Type: "boolean",
        }
    ]
};

function generateParentList(arr, level = 0) {
    var dash = "";
    for(i=0;i<level;i++) {dash += "—"};
    var result = [];
    _.each(arr, function(ar) {
        result.push({
            text: dash+ar.Title,
            value: ar.Id,
        });
        if(ar.SubMenu) {
            result = result.concat(generateParentList(ar.SubMenu, ++level))
            level--;
        }
    })
    return result;
}


function listTree(data) {
    var html = "<ul>";
    _.each(data, function(d) {
        html += "<li data-expanded="+d.Haschild+"><span><i class='"+d.Icon+"'></i></span>";
        html += d.Title;
        if(d.SubMenu) html += listTree(d.SubMenu);
        html += "</li>";
    })
    html += "</ul>";
    return html
}

function getPayloadForm(formData) {
    var obj = {};
    _.each(formData, function(o) {
        obj[o.Id] = o.Value();
    })
    return obj;
}

function generatePageId(treeArr, id) {
    var pageId = "";
    if(id == "") return pageId;
    for(var i = 0; i < treeArr.length; i++) {
        if(treeArr[i].Id == id) {
            pageId = treeArr[i].Title.replace(" ", "").toUpperCase();
            break;
        } else if (treeArr[i].SubMenu){
            pageId += treeArr[i].Title.replace(" ", "").toUpperCase() + generatePageId(treeArr[i].SubMenu, id)
        }
    }
    console.log(pageId);
    return pageId;
}

MenuAdm.handleDelete = function(e) {
    ajaxPost("/sysmenu/deletemenu", {
        Id: MenuAdm.selectedMenu().Id
    }, function(res) {
        if(!res.IsError) {
            MenuAdm.reloadTreeView();
        }
    })
    MenuAdm.resetForm();
}
MenuAdm.reloadTreeView = function(e) {
    var tree = $("#treeview").data("kendoTreeView");
    tree.dataSource.read();
}

MenuAdm.resetForm = function() {
    _.each(MenuAdm.Form.components, function(e) {
        e.Value("");
    })
    MenuAdm.Form.mode("");
    MenuAdm.Form.enabled(false);
}
MenuAdm.saveData = function(e) {
    var payload = getPayloadForm(MenuAdm.Form.components);
    if(MenuAdm.Form.mode() == "add") {
        payload.IndexMenu = parseInt(payload.IndexMenu, 10);
        payload.PageId = generatePageId(MenuAdm.treeMenu(), payload.Parent) + payload.Title.replace(" ", "").toUpperCase();
        payload.Id = ""+Date.now();
        ajaxPost("/sysmenu/savemenu", payload, function(res) {
            if(!res.IsError) {
                MenuAdm.Form.mode("");
                MenuAdm.Form.enabled(false);
                MenuAdm.reloadTreeView();
            }
        })
    } else if(MenuAdm.Form.mode() == "edit") {
        var selected = MenuAdm.selectedMenu();
        payload.Id = selected.Id;
        payload.PageId = selected.PageId;
        payload.IndexMenu = parseInt(payload.IndexMenu, 10);
        ajaxPost("/sysmenu/updatemenu", payload, function(res) {
            if(!res.IsError) {
                MenuAdm.reloadTreeView();
            }
        })
    }
    MenuAdm.resetForm();

}
MenuAdm.generateTreeView = function() {
    // $("#treeview").html(listTree(MenuAdm.treeMenu()));
    var data = new kendo.data.HierarchicalDataSource({
        transport: {
            read: function(o) {
                ajaxPost("/sysmenu/getselectmenu", {}, function(res) {
                    MenuAdm.rawMenu = _.orderBy(res.Data.Records, ['Parent', 'IndexMenu']);
                    MenuAdm.treeMenu(generateTreeMenu(MenuAdm.rawMenu));
                    var parent = [{ text: "- Top Level -", value: ""}]
                    parent = parent.concat(generateParentList(MenuAdm.treeMenu()));
                    MenuAdm.Form.components[0].Data(parent);
                    o.success({data: MenuAdm.treeMenu()});
                })
            }
        },
        schema: {
            data: 'data',
            model: {
                children: 'SubMenu',
                expanded: true
            }
        }
    });
    $("#treeview").html("");
    $("#treeview").kendoTreeView({
        dataSource: data,
        dataTextField: "Title",
        dataValueField: "Id",
        template: function(o) {
            return "<span class='"+o.item.Icon+"'></span>"+o.item.Title;
        },
        change: function(e) {
            var selected = this.dataItem(this.select());
            MenuAdm.selectedMenu(selected)
            MenuAdm.setupForm(selected);
        }
    });
}
MenuAdm.setupForm = function(obj) {
    MenuAdm.Form.enabled(true);
    MenuAdm.Form.mode("edit");
    MenuAdm.Form.components[0].Value(obj.Parent);
    MenuAdm.Form.components[1].Value(obj.Title);
    MenuAdm.Form.components[2].Value(obj.Url);
    MenuAdm.Form.components[3].Value(obj.Icon);
    MenuAdm.Form.components[4].Value(obj.IndexMenu);
    MenuAdm.Form.components[5].Value(obj.Enable);
}
MenuAdm.init = function() {
    MenuAdm.generateTreeView();
}

$(function() {
    MenuAdm.init();
})