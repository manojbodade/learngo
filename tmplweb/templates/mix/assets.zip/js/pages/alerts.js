var Alerts = {};
var serviceList = [
    {value: "ACCUMULO", title: "Accumulo"}, 
    {value: "AMBARI", title: "Ambari"}, 
    {value: "AMBARI_INFRA", title: "Ambari Infra"}, 
    {value: "AMBARI_METRICS", title: "Ambaru Metrucs"}, 
    {value: "FLUME", title: "Flume"}, 
    {value: "HBASE", title: "HBase"}, 
    {value: "HDFS", title: "HDFS"}, 
    {value: "KAFKA", title: "Kafka"}, 
    {value: "KNOX", title: "Knox"}, 
    {value: "SMARTSENSE", title: "SmartSense"}, 
    {value: "SPARK", title: "Spark"}, 
    {value: "YARN", title: "Yarn"}, 
    {value: "ZEPPELIN", title: "Zeppelin"}, 
    {value: "ZOOKEEPER", title: "Zookeeper"}, 
    {value: "HIVE", title: "Hive"}, 
    {value: "MAPREDUCE2", title: "MapReduce 2"}, 
    {value: "OOZIE", title: "Oozie"}
];

function ModalAlert(selector, data, startDate, endDate) {
    var self = this;
    self.selector = selector;
    self.data = data;
    self.startDate = startDate;
    self.endDate = endDate;

    self.form = {
        resolution: ko.observable(""),
        feedback: ko.observable("")
    };

    self.renderGrid = function() {
        var selector = $(self.selector).find("#gridDetail");
        selector.html("");
        selector.kendoGrid({
            dataSource: {
                transport: {
                    read: function(opt) {
                        var payload = {
                            ClusterId: self.data.ClusterId,
                            DefinitionId: self.data.DefId
                        };
                        if(self.startDate && self.endDate) {
                            payload.TimeStart = self.startDate;
                            payload.TimeEnd = self.endDate;
                        }
                        ajaxPost("/alert/infobydefinitionid", payload, function (res) {
                            opt.success({ data: res.Data, total: res.Data.length })
                        });
                    }
                },
                schema: {
                    data: "data",
                    total: "total"
                },
                pageSize: 5
            },
            pageable: {
                pageSizes: [5,10,25,50,100,"all"]
            },
            columns: [
                { title: "Alert", field: "Label" },
                { title: "Node", field: "HostName" },
                { title: "Last Status Update", field: "OriginalTimestamp", template: function(o) { return moment(o.OriginalTimestamp).format("MM/DD/YYYY HH:mm")} },
                { title: "Desc", field: "Text" },
                { title: "Remarks", template: function() {return "<textarea class='remarks' placeholder='Enter remarks here.'></textarea>"} }
            ]
        })
    }

    self.render = function() {
        $(self.selector).modal("show");
        self.renderGrid();
    }
}

function AlertGrid(selector, data) {
    var self = this;
    self.selector = selector;
    self.data = data;
    self.dataGrid = null;
    self.startDate = null;
    self.endDate = null;

    self.filter = {
        services: [],
        common: "",
        type: ["CRITICAL", "WARNING", "OK", "UNKNOWN"]
    }
    self.total = {
        CRITICAL: ko.observable(0),
        OK: ko.observable(0),
        WARNING: ko.observable(0),
        UNKNOWN: ko.observable(0)
    }
    self.colorFilter = {
        CRITICAL: ko.observable(true),
        WARNING: ko.observable(true),
        OK: ko.observable(true)
    }

    self.filterColor = function(type) {
        var currType = self.filter.type;
        if(currType.indexOf(type) != -1) _.pull(currType, type);
        else currType.push(type);
        self.filter.type = currType;
        self.colorFilter[type](!self.colorFilter[type]());
        self.filterData();
    }
    self.filterData = function() {
        self.filterService(self.data, self.filter.services)
            .then(function(data) {
                return self.filterDefinition(data, self.filter.common)
            })
            .then(function(data) {
                return _.filter(data, function(d) {
                    return self.filter.type.indexOf(d.State) != -1
                })
            })
            .then(function(data) {
                self.calculateState(data);
                self.dataGrid.dataSource.data(data);
                self.refresh();
            });
    }
    self.filterService = function(data, search) {
        return new Promise(function(res, rej) {
            if(search != "") {
                res(_.filter(data, function(d) {
                    return search.indexOf(d.ServiceName) != -1
                }));
            } else {
                res(data);
            }
        })
    }
    self.filterDefinition = function(dataFilter, search) {
        if(search != "") {
            var data = _.filter(dataFilter, function(d) {
                return d.DefName.indexOf(search) != -1
            });
            return data;
        } else {
            return dataFilter;
        }
    }
    self.refresh = function() {
        self.dataGrid.refresh();
    }
    self.calculateState = function(data) {
        var data = data ? data : self.data;
        var total = self.total;
        total.CRITICAL(0);
        total.WARNING(0);
        total.OK(0);
        total.UNKNOWN(0);
        _.each(data, function(d) {
            total[d.State]((total[d.State]()+1));
        })
    }
    self.render = function() {
        var selector = $(self.selector);
        selector.html("");
        selector.kendoGrid({
            dataSource: {
                transport: {
                    read: function(opt) {
                        var payload = {};
                        if(self.startDate && self.endDate) {
                            payload.TimeStart = self.startDate;
                            payload.TimeEnd = self.endDate;
                        }
                        ajaxPost("/alert/infobycluster", payload, function (r) {
                            self.data = r.Data;
                            self.calculateState();
                            opt.success({ data: r.Data, total: r.Data.length });
                        });
                    }
                },
                schema: {
                    data: "data",
                    total: "total",
                },
            },
            filterable: true,
            selectable: 'row',
            change: function(o){
                var data = this.dataItem(this.select());
                Alerts.modal.title(data.ClusterName +" | "+data.ServiceName+" | "+data.State);
                Alerts.modal.content(new ModalAlert("#modalDetail", data, self.startDate, self.endDate));
                Alerts.modal.content().render();
            },
            pageable: {
                numeric: true,
                pageSizes: [10, 25, 50, 100, "all"]
            },
            columns: [
                { title: "Cluster Name", field: "ClusterName", filterable: { multi: true, search: true }},
                { title: "Service Group", field: "ServiceName", filterable: false },
                { title: "Label", field: "Label", filterable: false},
                { title: "State", field: "State", filterable: false, template: function(d) { 
                    if(d.Count > 1) return d.State +" ["+d.Count+"]"
                    else return d.State
                 } },
                { title: "Date", field: "Timestamp", filterable: false, template: function(d) { return moment(d.Timestamp).format("MM/DD/YYYY HH:mm")}}
            ],
            rowTemplate: function(o) {
                var state = "";
                if(o.Count > 1) state = o.State +" ["+o.Count+"]";
                else state = o.State
                var stateType = Alerts.getType(o.State);
                return '<tr class="'+stateType+'" data-uid="'+o.uid+'">' +
                        '<td>'+o.ClusterName+'</td>' +
                        '<td>'+o.ServiceName+'</td>' +
                        '<td>'+o.Label+'</td>' +
                        '<td>'+state+'</td>' +
                        '<td>'+moment(o.Timestamp).format("MM/DD/YYYY HH:mm")+'</td>' +
                        '</tr>';
            }
        });
        self.dataGrid = selector.data("kendoGrid");
    }
}

Alerts.config = {
    grid: ko.observable(),
}
Alerts.modal = {
    title: ko.observable(""),
    content: ko.observable(),
}

Alerts.filter = {
    service: ko.observableArray([]),
    commonSearch: ko.observable(""),
    startDate: ko.observable(new Date()),
    endDate: ko.observable(new Date()),
    rangedDate: ko.observable(moment(new Date()).format("MM/DD/YYYY HH:mm") +" - "+moment(new Date()).format("MM/DD/YYYY HH:mm"))
}
Alerts.filter.service.subscribe(function(val) {
    Alerts.config.grid().filter.services = val;
    Alerts.config.grid().filterData();
});
Alerts.filter.rangedDate.subscribe(function(val) {
    Alerts.config.grid().startDate = Alerts.filter.startDate();
    Alerts.config.grid().endDate = Alerts.filter.endDate();
    Alerts.config.grid().dataGrid.dataSource.read();
});
Alerts.filter.commonSearch.subscribe(function(val) {
    Alerts.config.grid().filter.common = val;
    Alerts.config.grid().filterData();
})

Alerts.getType = function(status) {
    switch(status) {
        case "CRITICAL":
            return "red";
        case "OK":
            return "green";
        case "WARNING":
            return "amber";
    }
}

Alerts.getData = function() {
    return new Promise(function(res, rej) {
        ajaxPost("/alert/infobycluster", {}, function (r) {
            res(r.Data);
        });
    })
}

Alerts.init = function () {
    Alerts.config.grid(new AlertGrid("#grid"));
    Alerts.config.grid().render();
}

$(function() {
    Alerts.init();

    $("input[name='daterange']").daterangepicker({
        "alwaysShowCalendars": true,
        "timePicker": true,
        "timePicker24Hour": true,
        "locale": {
            "format": "MM/DD/YYYY HH:mm"
        },
        "startDate": Alerts.filter.startDate(),
        "endDate": Alerts.filter.endDate(),
        "ranges": {
            "1 Hour": [moment().subtract(1, "hours").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Day": [moment().subtract(1, "days").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Week": [moment().subtract(1, "weeks").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
            "1 Month": [moment().subtract(1, "months").format("MM/DD/YYYY HH:mm"), moment().format("MM/DD/YYYY HH:mm")],
        }
    }, function(start, end) {
        Alerts.filter.endDate(end.format("YYYYMMDDHHmmss"));
        Alerts.filter.startDate(start.format("YYYYMMDDHHmmss"));
    });
})