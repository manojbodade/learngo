var Alerts = {};
var serviceList = [
    {value: "ACCUMULO", title: "Accumulo"}, 
    {value: "AMBARI", title: "Ambari"}, 
    {value: "AMBARI_INFRA", title: "Ambari Infra"}, 
    {value: "AMBARI_METRICS", title: "Ambaru Metrucs"}, 
    {value: "FLUME", title: "Flume"}, 
    {value: "HBASE", title: "HBase"}, 
    {value: "HDFS", title: "HDFS"}, 
    {value: "KAFKA", title: "Kafka"}, 
    {value: "KNOX", title: "Knox"}, 
    {value: "SMARTSENSE", title: "SmartSense"}, 
    {value: "SPARK", title: "Spark"}, 
    {value: "YARN", title: "Yarn"}, 
    {value: "ZEPPELIN", title: "Zeppelin"}, 
    {value: "ZOOKEEPER", title: "Zookeeper"}, 
    {value: "HIVE", title: "Hive"}, 
    {value: "MAPREDUCE2", title: "MapReduce 2"}, 
    {value: "OOZIE", title: "Oozie"}
];

function ModalAlert(selector, data) {
    var self = this;
    self.selector = selector;
    self.data = data;

    self.form = {
        resolution: ko.observable(""),
        feedback: ko.observable("")
    };

    self.renderGrid = function() {
        var selector = $(self.selector).find("#gridDetail");
        selector.html("");
        selector.kendoGrid({
            dataSource: {
                transport: {
                    read: function(opt) {
                        ajaxPost("/alert/infobydefinitionid", {
                            ClusterId: self.data.ClusterId,
                            DefinitionId: self.data.DefId
                        }, function (res) {
                            opt.success({ data: res.Data, total: res.Data.length })
                        });
                    }
                },
                schema: {
                    data: "data",
                    total: "total"
                },
                pageSize: 5
            },
            pageable: true,
            columns: [
                { title: "Alert", field: "Label" },
                { title: "Node", field: "HostName" },
                { title: "Last Status Update", field: "DefName" },
                { title: "Desc", field: "Text" },
                { title: "Comments" }
            ]
        })
    }

    self.render = function() {
        $(self.selector).modal("show");
        self.renderGrid();
    }
}

function AlertGrid(selector, data) {
    var self = this;
    self.selector = selector;
    self.data = data;
    self.dataGrid = null;

    self.filterService = function(search) {
        if(search != "") {
            var data = _.filter(self.data, function(d) {
                return d.ServiceName == search
            });
            self.dataGrid.dataSource.data(data);
        } else {
            self.dataGrid.read();
        }
        self.refresh();
    }
    self.refresh = function() {
        self.dataGrid.refresh();
    }
    self.render = function() {
        var selector = $(self.selector);
        selector.html("");
        selector.kendoGrid({
            dataSource: {
                data: self.data,
                pageSize: 10,
            },
            selectable: 'row',
            change: function(o){
                var data = this.dataItem(this.select());
                Alerts.modal.title(data.ClusterName +" | "+data.ServiceName+" | "+data.State);
                Alerts.modal.content(new ModalAlert("#modalDetail", data));
                Alerts.modal.content().render();
            },
            pageable: true,
            columns: [
                { title: "Cluster Name", field: "ClusterName" },
                { title: "Service Group", field: "ServiceName" },
                { title: "Label", field: "Label"},
                { title: "State", field: "State" },
                { title: "Date", field: "Timestamp", template: function(d) { return moment(d.Timestamp).format("MM/DD/YYYY HH:mm")}}
            ],
            rowTemplate: function(o) {
                var stateType = Alerts.getType(o.State);
                return '<tr class="'+stateType+'" data-uid="'+o.uid+'">' +
                        '<td>'+o.ClusterName+'</td>' +
                        '<td>'+o.ServiceName+'</td>' +
                        '<td>'+o.Label+'</td>' +
                        '<td>'+o.State+'</td>' +
                        '<td>'+moment(o.Timestamp).format("MM/DD/YYYY HH:mm")+'</td>' +
                        '</tr>';
            }
        });
        self.dataGrid = selector.data("kendoGrid");
    }
}

Alerts.config = {
    grid: ko.observable(),
}
Alerts.modal = {
    title: ko.observable(""),
    content: ko.observable(),
}

Alerts.filter = {
    service: ko.observable(""),
    commonSearch: ko.observable(""),
}
Alerts.filter.service.subscribe(function(val) {
    Alerts.config.grid().filterService(val);
})

Alerts.getType = function(status) {
    switch(status) {
        case "CRITICAL":
            return "red";
        case "OK":
            return "green";
        case "WARNING":
            return "amber";
    }
}

Alerts.getData = function() {
    return new Promise(function(res, rej) {
        ajaxPost("/alert/infobycluster", {}, function (r) {
            res(r.Data);
        });
    })
}

Alerts.init = function () {
    Alerts.getData()
          .then(function(data) {
            Alerts.config.grid(new AlertGrid("#grid", data));
            return Alerts.config.grid();
          })
          .then(function(grid) {
              grid.render();
          })
}

$(function() {
    Alerts.init();
})