top -bn1
