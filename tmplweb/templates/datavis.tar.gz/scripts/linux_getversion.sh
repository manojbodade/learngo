cat /proc/version
