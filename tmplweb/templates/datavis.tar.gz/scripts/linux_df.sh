df -h
