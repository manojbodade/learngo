var User = {};

User.Filter = {
    Username: {
        Value: ko.observableArray([]),
        Data: ko.observableArray([]),
    },
    Role: {
        Value: ko.observableArray([]),
        Data: ko.observableArray([])
    },
    Status: {
        Value: ko.observable(true),
    }
}
User.Role = ko.observableArray([]);
User.Modal = {
    Id: ko.observable(""),
    Fullname: ko.observable(""),
    Email: ko.observable(""),
    Username: ko.observable(""),
    Password: ko.observable(""),
    Phone: ko.observable(""),
    Roles: ko.observable(""),
    Enable: ko.observable(true),

}

User.getRole = function() {
    ajaxPost("/sysrole/getdata", {}, function(res) {
        User.Role(_.map(res.Data.Records, function(d) { return d.Name }));
    })
}

User.handleSave = function() {
    var payload = ko.mapping.toJS(User.Modal);
    ajaxPost("/user/savedata", payload, function(res) {
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
            User.reloadGrid();
        }
    })
}

User.reloadGrid = function() {
    var grid = $("#gridUser").data("kendoGrid");
    grid.dataSource.read();
    grid.refresh();
}

User.generateGridUser = function() {
    $("#gridUser").kendoGrid({
        dataSource: {
            transport: {
                read: function(opt) {
                    var filter = User.Filter;
                    ajaxPost("/user/getdata", {
                        Username: filter.Username.Value(),
                        Role: filter.Role.Value(),
                        Status: filter.Status.Value()
                    }, function(res) {
                        opt.success(res.Data.Records);
                    })
                }
            },
            pageSize: 10,
        },
        selectable: "row",
        pageable: {
            numeric: true,
            previousNext: true,
            message: {
                display: "Showing {2} data items"
            }
        },
        change: function(o) {
            var data = this.dataItem(this.select());
            var modal = User.Modal;
            _.each(Object.keys(modal), function(m) {
                if(m != "Password") modal[m](data[m]);
            });
            $("#modalDetail").modal("show");
        },
        columns: [
            { title: "Username", field: "Username" },
            { title: "Full Name", field: "Fullname" },
            { title: "Email", field: "Email" },
            { title: "Phone", field: "Phone" },
            { title: "Status", field: "Enable", template: function(o) { return o.Enable ? "Enable" : "Disable" }},
            { title: "Roles", field: "Roles"}
        ]
    })
}


User.init = function() {
    User.generateGridUser();
    User.getRole();
}

$(function() {
    User.init();
})