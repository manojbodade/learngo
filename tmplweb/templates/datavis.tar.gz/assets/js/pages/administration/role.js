var Role = {};
Role.RoleNameData = ko.observableArray([]);
Role.Filter = {
    Name: { 
        Value: ko.observableArray(),
        Data: ko.observableArray([]),
    },
    Status: {
        Value: ko.observable(true),
    }
}
Role.Filter.Status.Value.subscribe(function() {
    Role.reloadGrid();
})
Role.Modal = {
    Id: ko.observable(""),
    Name: ko.observable(""),
    Status: ko.observable(true),
    Landing: ko.observable(""),
    Menu: ko.observableArray([]),
}

function handleCheckbox(el, id, type) {
    var menu = Role.findMenuObservable(id);
    var field = ["Checkall", "Access", "Create", "Edit", "Delete", "View", "Approve", "Process"];
    if(type == "Checkall") {
        var checkboxes = $(el).closest("tr").find("input");
        var current = menu.Checkall();
        if(current) {
            _.each(checkboxes.slice(1), function(c) {
                $(c).prop("checked", false);
                console.log($(c).is(":checked"))
            });
            _.each(field, function(f) {
                menu[f](false);
            })
        } else {
            _.each(checkboxes.slice(1), function(c) {
                $(c).prop("checked", true);
            });
            _.each(field, function(f) {
                menu[f](true);
            })
        }
    } else {
        var current = menu[type]();
        if(current) {
            var checkall = $(el).closest("tr").find("input[data-type='Checkall']");
            $(checkall).prop("checked", false);
            menu["Checkall"](false);
        } else {
            var allCheckboxes = $(el).closest("tr").find("input");
            var checkboxes = allCheckboxes.slice(1);
            var checkallboxes = allCheckboxes[0];
            var isCheckall = true;
            _.each(checkboxes, function(c) {
                if(!$(c).is(":checked")){
                    isCheckall = false;
                    return;
                }
            });
            if(isCheckall) {
                $(checkallboxes).prop("checked", true)
                _.each(field, function(f) {
                    menu[f](true);
                })
            } else {
                $(checkallboxes).prop("checked", false)
                menu["Checkall"](false);
            }
        }
        menu[type](!current);
    }
}

Role.handleSave = function(e) {
    ajaxPost("/sysrole/savedata", ko.mapping.toJS(Role.Modal), function(res) {
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
        }
    })
}
Role.findIndexMenuObservable = function(id) {
    return _.findIndex(Role.Modal.Menu(), function(m) {
        return m.Menuid() == id;
    })
}
Role.findMenuObservable = function(id) {
    return _.find(Role.Modal.Menu(), function(m) {
        return m.Menuid() == id;
    })
}
Role.applyCheckboxTreeTemplate = function(columns) {
    return _.map(columns, function(c) {
        c.headerAttributes = {"class": "text-center"};
        c.attributes = {"class": "text-center"};
        c.template = function(o) {
            var value = Role.findMenuObservable(o.Menuid)
            // var idx = Role.findIndexMenuObservable(o.Menuid);
            return '<input type="checkbox" data-type="'+this.field+'" onclick="handleCheckbox(this, \''+o.Menuid+'\',\''+this.field+'\')" '+(value[this.field]() ? "checked='checked'" : '')+'" />'
            // return '<input type="checkbox" data-bind="checked: Role.Menu['+idx+']['+this.field+']" />'
        }
        return c;
    })
}
Role.reloadGrid = function() {
    var grid = $("#gridRole").data("kendoGrid");
    grid.dataSource.read();
    grid.refresh();
}
Role.generateTreeListMenuRole = function(menu) {
    console.log(menu);
    var dataSource = new kendo.data.TreeListDataSource({
        data: menu,
          schema: {
              model: {
                  id: "Menuid",
                  fields: {
                      parentId: {field: "Parent", type: "string", nullable: true}
                  },
                  expanded: true
              }
          }
    });
    var columns = [{ field: "Menuname", title: "Title", width: 150, headerAttributes: {"class": "text-center"} }],
    columns = columns.concat(Role.applyCheckboxTreeTemplate([
        { field: "Checkall",  title: "Check All" },
        { field: "Access", title: "Access"},
        { field: "Create", title: "Create" },
        { field: "Edit", title: "Edit" },
        { field: "Delete", title: "Delete" },
        { field: "View", title: "View" },
        { field: "Approve", title: "Approve" },
        { field: "Process", title: "Process" }
    ]));
    $("#gridDetailRole").html("");
    $("#gridDetailRole").kendoTreeList({
        dataSource: dataSource,
        columns: columns
    });
}

Role.generateGridRole = function() {
    $("#gridRole").kendoGrid({
        dataSource: {
            transport: {
                read: function(opt) {
                    ajaxPost("/sysrole/getdata", {
                        Name: Role.Filter.Name.Value(),
                        Status: Role.Filter.Status.Value()
                    }, function(res) {
                        opt.success(res.Data.Records);
                    })
                }
            },
            pageSize: 10,
        },
        selectable: 'row',
        change: function(e) {
            var data = this.dataItem(this.select());
            ajaxPost("/sysrole/getmenuedit", {Id: data.Id, Name: data.Name }, function(res) {
                var data = res.Data.Records[0];
                Role.Modal.Name(data.Name);
                Role.Modal.Status(data.Status);
                Role.Modal.Landing(data.Landing);
                Role.Modal.Id(data.Id);
                // Role.Modal.Menu(data.Menu);
                ko.mapping.fromJS(data.Menu, {}, Role.Modal.Menu);
                Role.generateTreeListMenuRole(_.map(data.Menu, function(o) {
                    o.Parent = o.Parent == "" ? null : o.Parent;
                    return o;
                }));
                $("#modalDetail").modal('show');
            })
        },
        pageable: {
            numeric: true,
            previousNext: true,
            messages: {
                display: "Showing {2} data items",
            }
        },
        columns: [
            { title: "Role Name", field: "Name" },
            { title: "Status", field: "Status", template: function(o) {return o.Status ? "Active" : "Inactive"}}
        ],
    })
}

Role.init = function() {
    ajaxPost("/sysrole/getdata", {}, function(res) {
        if(!res.IsError) {
            var data = _.map(res.Data.Records, function(d) { return d.Name });
            Role.Filter.Name.Data(data);
            Role.RoleNameData(res.Data.Records);
        }
    })
    Role.generateGridRole();
}

$(document).ready(function() {
    Role.init();
})