var Service = {};

Service.Filter = {

}


Service.Modal = {
    Mode: ko.observable("add"),// add || edit
    Components: {
        Id: {
            Value: ko.observable(""),
            Visible: false,
        },
        Name: {
            Value: ko.observable(""),
            Visible: true,
        }
    }
}

Service.handleSave = function() {
    var payload = Object.keys(Service.Modal.Components).reduce(function(prev, next) {
        prev[next] = Service.Modal.Components[next].Value();
        return prev;
    }, {});
    ajaxPost("/service/save", payload, function(res){
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
            Service.reloadGrid();
            Service.resetModal();
        }
    })
}
Service.handleDelete = function() {
    var payload = {
        Id: Service.Modal.Components.Id.Value()
    };
    ajaxPost("/service/delete", payload, function(res) {
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
            Service.reloadGrid();
            Service.resetModal();
        }
    })
}

Service.resetModal = function() {
    _.each(Object.keys(Service.Modal.Components), function(k) {
        Service.Modal.Components[k].Value("");
    });
    Service.Modal.Mode("add");
}

Service.reloadGrid = function() {
    var grid = $("#gridService").data("kendoGrid");
    grid.dataSource.read();
    grid.refresh();
}

Service.generateGrid = function() {
    $("#gridService").kendoGrid({
        dataSource: {
            transport: {
                read: function(opt) {
                    ajaxPost("/service/getdata", {}, function(res) {
                        opt.success(res.Data.Records);
                    })
                }
            },
            pageSize: 15
        },
        pageable: {
            numeric: true,
            previousNext: true,
            message: {
                display: "Showing {2} data items"
            }
        },
        selectable: "row",
        change: function() {
            var data = this.dataItem(this.select());
            Service.Modal.Components.Id.Value(data.Id);
            Service.Modal.Components.Name.Value(data.Name);
            Service.Modal.Mode("edit");
            $("#modalDetail").modal('show');
        },
        columns: [
            { title: "Name", field: "Name" },
            { title: "Create By", field: "CreBy" },
            { title: "Create At", field: "CreDate", template: function(o) { return moment(o.CreDate).format("dd, DD MMM YYYY")} },
            { title: "Updated By", field: "UpdBy" },
            { title: "Update At", field: "UpdDate", template: function(o) { return moment(o.UpdDate).format("dd, DD MMM YYYY")} }
        ]
    })
}

Service.init = function() {
    this.generateGrid();
}

$(function() {
    Service.init();
})