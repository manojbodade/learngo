var Cluster = {};

Cluster.Modal = {
    Mode: ko.observable("add"),// add || edit
    Components: {
        Id: ko.observable(""),
        ClusterName: ko.observable(""),
        ClusterType: ko.observable(""),
        Username: ko.observable(""),
        Password: ko.observable(""),
        URL: ko.observable(""),
        IpAddress : ko.observable(""),
        Nodes: ko.observableArray([]),
    }
}
Cluster.deleteNodes = function(idx) {
    var currentNodes = Cluster.Modal.Components.Nodes();
    _.pullAt(currentNodes, idx);
    Cluster.Modal.Components.Nodes(currentNodes);
    Cluster.Modal.Components.Nodes.valueHasMutated();
}
Cluster.addNodeForm = function() {
    var currentNodes = Cluster.Modal.Components.Nodes();
    currentNodes.push({
        NodeIP: ko.observable(""),
        NodeName: ko.observable("")
    });
    Cluster.Modal.Components.Nodes(currentNodes);
}
Cluster.handleSave = function() {
    var comp = Cluster.Modal.Components;
    var payload = {
        Id: comp.Id(),
        ClusterName: comp.ClusterName(),
        ClusterType: comp.ClusterType(),
        AmbariConfig: {
            Username: comp.Username(),
            Password: comp.Password(),
            URL: comp.URL()
        },
        IpAddress: comp.IpAddress(),
        Nodes: _.map(comp.Nodes(), function(o) { return { NodeIP: o.NodeIP(), NodeName: o.NodeName() } }),
    }
    ajaxPost("/cluster/save", payload, function(res){
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
            Cluster.reloadGrid();
            Cluster.resetModal();
        }
    })
}
Cluster.handleDelete = function() {
    var payload = {
        Id: Cluster.Modal.Components.Id()
    };
    ajaxPost("/cluster/delete", payload, function(res) {
        if(!res.IsError) {
            $("#modalDetail").modal('hide');
            Cluster.reloadGrid();
            Cluster.resetModal();
        }
    })
}

Cluster.resetModal = function() {
    _.each(Object.keys(Cluster.Modal.Components), function(k) {
        if(k == "Nodes") Cluster.Modal.Components[k]([]);
        else Cluster.Modal.Components[k]("");
    });
    Cluster.Modal.Mode("add");
}

Cluster.reloadGrid = function() {
    var grid = $("#gridCluster").data("kendoGrid");
    grid.dataSource.read();
    grid.refresh();
}

Cluster.generateGrid = function() {
    $("#gridCluster").kendoGrid({
        dataSource: {
            transport: {
                read: function(opt) {
                    ajaxPost("/cluster/getdata", {}, function(res) {
                        opt.success(res.Data.Records);
                    })
                }
            },
            pageSize: 15
        },
        detailTemplate: "Nodes: <div class='detailGrid'></div>",
        detailInit: function(e) {
            e.detailRow.find(".detailGrid").kendoGrid({
                dataSource: e.data.Nodes,
                columns: [
                    { title: "Node IP", field: "NodeIP" },
                    { title: "Node Name", field: "NodeName" },
                ]
            })
        },
        dataBound: function(){
            this.collapseGroup(".k-detail-row");
        },
        pageable: {
            numeric: true,
            previousNext: true,
            message: {
                display: "Showing {2} data items"
            }
        },
        selectable: "row",
        change: function() {
            var data = this.dataItem(this.select());
            Cluster.Modal.Components.Id(data.Id);
            Cluster.Modal.Components.ClusterName(data.ClusterName);
            Cluster.Modal.Components.ClusterType(data.ClusterType);
            Cluster.Modal.Components.Username(data.AmbariConfig.Username);
            Cluster.Modal.Components.Password(data.AmbariConfig.Password);
            Cluster.Modal.Components.URL(data.AmbariConfig.URL);
            Cluster.Modal.Components.IpAddress(data.IpAddress);
            ko.mapping.fromJS(data.Nodes, {}, Cluster.Modal.Components.Nodes);
            Cluster.Modal.Components.Nodes.valueHasMutated();
            Cluster.Modal.Mode("edit");
            $("#modalDetail").modal('show');
        },
        columns: [
            { title: "ID", field: "Id" },
            { title: "Name", field: "ClusterName" },
            { title: "IP Address", field: "IpAddress" },
            { title: "Total Nodes", field: "Nodes", template : function(o) { return o.Nodes.length } },
            { title: "Username", field: "AmbariConfig.Username"},
            { title: "URL", field: "AmbariConfig.URL"},
            { title: "Create At", field: "CreDate", template: function(o) { return moment(o.CreDate).format("dd, DD MMM YYYY")} },
            { title: "Update At", field: "UpdDate", template: function(o) { return moment(o.UpdDate).format("dd, DD MMM YYYY")} }
        ]
    })
}

Cluster.init = function() {
    this.generateGrid();
}

$(function() {
    Cluster.init();
})