var OPHadoop = {};
OPHadoop.OpcData = ko.observableArray([]);

function OpcBarChart(name, id, data) {
    var self = this;
    self.pct = ko.observable(0);
    self.diskUsedInf = ko.observable("");
    self.diskFree = ko.observable("");
    self.type = ko.observable("");

    self.render = function() {
        var pct = data.Pct.toFixed(2);
        var free = data.Free.toFixed(2);
        var used = data.Used.toFixed(2);
        if(pct > 85) self.type("bar red");
        else if(pct > 70) self.type("bar yellow");
        else self.type("bar green");
        self.pct(pct);
        self.diskUsedInf("("+pct+"%) "+used+data.Label+" (used).");
        self.diskFree("("+(100 - pct)+"%) "+free+data.Label+" (balanced).");
    }
}

function OpcAreaChart(name, id, data) {
    var self = this;
    self.process = ko.observable("");
    self.selector = "#opChartArea-"+id

    self.formatData = function(data) {
        var newFormat = [];
        var colors = ["rgb(0, 117, 176)", "rgb(0, 92, 132)", "rgb(63, 156, 53)", "rgb(105, 190, 40)"];
        var keys = Object.keys(data);
        for(var i = 0; i < keys.length; i++) {
            newFormat.push({
                name: keys[i],
                data: data[keys[i]],
                color: colors[i]
            });
        }
        return newFormat;
    }
    self.render = function() {
        self.process("Current: "+data.Process+" processes");

        var series = self.formatData(data.Data);
        var selector = $(self.selector).find(".area");
        selector.html("");
        selector.kendoSparkline({
            seriesDefaults: {
                type: "area",
                field: "Val"
            },
            chartArea: {
                height: 125
            },
            series: series,
            tooltip: {
                template: function(o) {
                    var data = o.dataItem;
                    var d = new Date(0);
                    d.setUTCSeconds(data.Ts);
                    return data.Val+"% at "+moment(d).format("HH:mm:ss");
                }
            },
        })
    }
}

function OpcLineChart(name, id, data) {
    var self = this;
    self.maxInf = ko.observable("");
    self.selector = "#opChartLine-"+id;

    self.formatData = function(data) {
        return _.map(data, function(d) {
            return {
                Val: (d.Val / 1048576).toFixed(2),
                Ts: d.Ts
            }
        })
    }
    self.render = function() {
        var max = (data.Max / 1048576).toFixed(2);
        self.maxInf("Max: "+max+"GB");
        var selector = $(self.selector).find(".line");
        selector.html("");
        var series = self.formatData(data.Timeline);
        selector.kendoSparkline({
            data: series,
            seriesDefaults: {
                type: "line",
                line: {
                    width: 2
                },
                field: "Val",
                color: "rgb(40, 144, 192)"
            },
            chartArea: {
                height: 125
            },
            valueAxis:{
                plotBands: [
                    {
                        from: max,
                        to: max + 2,
                        color: "#000",
                    }
                ]
            },
            tooltip: {
                template: function(o) {
                    var data = o.dataItem;
                    var d = new Date(0);
                    d.setUTCSeconds(data.Ts);
                    return data.Val+"GB at "+moment(d).format("HH:mm:ss");
                }
            },
        })
    }
}

function OpcCircleChart(name, id, data) {
    var self = this;
    self.selector = "#opChartCircle-"+id;

    self.getCircleChart = function(pct) {
        return '<svg class="circle-chart" viewbox="0 0 33.83098862 33.83098862" width="150" height="150" xmlns="http://www.w3.org/2000/svg"><circle class="circle-chart__background" stroke="rgb(195, 226, 193)" stroke-width="2" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><circle class="circle-chart__circle" stroke="rgb(63, 156, 53)" stroke-width="2" stroke-dasharray="'+pct+',100" stroke-linecap="round" fill="none" cx="16.91549431" cy="16.91549431" r="15.91549431" /><g class="circle-chart__info"><text class="circle-chart__percent" x="16.91549431" y="16" alignment-baseline="central" text-anchor="middle" fill="rgb(106, 193, 123)" font-size="6">'+pct+'%</text></g></svg>';
    }
    self.render = function() {
        var html = self.getCircleChart(data.Current.toFixed(2));
        $(self.selector).html(html);
    }
}

OPHadoop.getData = function() {
    return new Promise(function(res, rej) {
        ajaxPost("/opchadoop/getclusterstatus",{}, function(r) {
            res(r.Data);
        }, function() {
            rej("Failed get data");
        })
    });
}
OPHadoop.buildData = function(data) {
    var newFormat = [];
    for(var i = 0; i < data.length; i++) {
        var d = data[i];
        newFormat.push({
            name: d.ClusterName,
            id: d.ClusterId,
            storage: new OpcBarChart(d.ClusterName, d.ClusterId, d.Storage),
            io: new OpcAreaChart(d.ClusterName, d.ClusterId, d.IOinfo),
            memory: new OpcLineChart(d.ClusterName, d.ClusterId, d.Memory),
            cpu: new OpcCircleChart(d.ClusterName, d.ClusterId, d.CPU),
        })
    }
    return newFormat;
}
OPHadoop.render = function(interval) {
    OPHadoop.getData()
    .then(function(data) {
        var newData = OPHadoop.buildData(data);
        OPHadoop.OpcData(newData);
    })
    .then(function() {
        var data = OPHadoop.OpcData();
        _.each(data, function(d) {
            d.storage.render();
            d.io.render();
            d.memory.render();
            d.cpu.render();
        })
    })
    .catch(function(msg) {
        if(interval) clearInterval(interval);
        alert(msg);
    })
}
OPHadoop.init = function() {
    OPHadoop.render();
    var interval = setInterval(function() {
        OPHadoop.render(interval);
    }, 60000);
}

$(function() {
    OPHadoop.init();
})