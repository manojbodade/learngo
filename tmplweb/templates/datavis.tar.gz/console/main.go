package main

import (
	tk "github.com/eaciit/toolkit"
)

func main() {
	tk.Println("Init reader ")
}
